> **数据库开源周报 · 第 N 期**
> 每周 5 分钟，追踪数据库工具与生态的一手动态。
> _2026-08-10_

> 📌 **数据边界**：本报告聚焦数据库**工具与生态**。数据库内核（PostgreSQL/MySQL/TiDB 等）的版本与发版请以各厂商官方渠道为准。
> 📌 **配套阅读**：本期 [**运维工具合辑周报**](https://mp.weixin.qq.com/)（6 类工具本周动态体检）

---


## ✏️ 本期导语

本周 star 异常上涨（≥100）5 个：write-you-a-vector-db（+782）、drawdb（+434）、WrenAI（+328）、Chat2DB（+278）、LiquiDB（+119）。
新入榜工具 22 个。
本周 34 个工具发版。
无 License 变更。
详见下方各栏。


## 🔍 本周精选解读

### 1. WrenAI 0.29.2

[Canner/WrenAI](https://github.com/Canner/WrenAI) · ⭐ 17.2k（+328） · [发版说明](https://github.com/Canner/WrenAI/releases/tag/0.29.2)

**发生了什么**：WrenAI 于本周发布 0.29.2 版本。本次发版的核心变更包括：将 Databricks 添加到支持的数据库列表；在 wren-ai-service 中新增从 ibis 获取知识的功能，并为 LLMProvider 增加系统提示词处理能力；同时进行了多项依赖升级与安全修复，涉及 litellm、grpc-go、fast-xml-parser、lodash 等多个组件，以解决已知 CVE 漏洞。此外，wren-ui 升级了 vega-lite 版本，并在侧边栏新增了 Wren AI Cloud 升级入口点。

**为什么值得关注**：WrenAI 是一个开源的生成式商业智能（GenBI）引擎，面向 AI 代理场景，解决自然语言到受治理 SQL 转换的问题。它通过开放的 AI 上下文层和语义层（MDL），将业务定义、批准指标、示例和公司文档等非结构化知识纳入版本控制，使 AI 代理生成的 SQL 和仪表板结果可信且可审查。该工具支持 22 种以上数据源（如 BigQuery、Snowflake、PostgreSQL、ClickHouse、Databricks 等），核心能力涵盖受治理的 text-to-SQL、基于 WebAssembly 的仪表板生成与部署、以及知识管理与记忆检索。其设计强调开放性和可审查性，语义定义以 Git 友好文件形式存储，并采用 Apache 2.0 开源协议。

### 2. Chat2DB v5.3.3

[OtterMind/Chat2DB](https://github.com/OtterMind/Chat2DB) · ⭐ 27.9k（+278） · [发版说明](https://github.com/OtterMind/Chat2DB/releases/tag/v5.3.3)

**发生了什么**：Chat2DB Community 5.3.3 于本周发布，主要聚焦桌面端工作区、集成终端和本地文件体验的改进。该版本新增了集成终端、本地文件预览、工作区分屏、可配置的 SQL 与数据库树快捷键、MiniMax 模型提供商支持，以及跨数据库方言的无条件标识符引用功能。同时，修复了 95 个问题，涵盖跨数据库的 SQL 与 DDL 安全、DML 与分页校验、存储一致性、结果网格、AI 流所有权、BI 图表、macOS 打包与启动等多个方面。此外，还包含 4 项开发与发布工程相关的变更，如严格化发布元数据生成和桌面端字节码验证。

**为什么值得关注**：Chat2DB 是一款由 OtterMind 支持的 AI 驱动的数据库客户端和 SQL 工作区，面向开发者、DBA、分析师和数据团队。它支持 40 多种数据库，包括 MySQL、PostgreSQL、Oracle、SQL Server、ClickHouse、MongoDB、Redis 等，并可通过配置扩展新的 JDBC 数据库。其核心能力包括完整的 SQL 编辑、补全、格式化与执行，AI 助手（可接入自有模型）用于生成、解释和优化 SQL，以及数据库元数据浏览、对象管理（DDL/DML）、数据就地编辑、数据导入导出、仪表盘与图表等功能。该工具以本地优先、单用户模式运行，注重数据安全，使用 AES-256-GCM 加密存储的数据源密码和 AI API 密钥。

### 3. grafana v13.0.6

[grafana/grafana](https://github.com/grafana/grafana) · ⭐ 76.2k（+94） · [发版说明](https://github.com/grafana/grafana/releases/tag/v13.0.6)

**发生了什么**：grafana/grafana 本周发布了 v13.0.6 版本。该版本为维护性发版，主要包含 bug 修复和稳定性改进，具体变更内容需参考官方 Release Notes 页面。用户可通过官方下载页面获取该版本，并查阅“What's new highlights”了解新特性概览。

**为什么值得关注**：Grafana 是一个开源的可观测性与数据可视化平台，旨在帮助用户查询、可视化、告警并理解来自多种数据源（如 Prometheus、Loki、Elasticsearch、InfluxDB、Postgres 等）的指标、日志和追踪数据。其核心能力包括：支持多种可视化面板与动态可复用仪表盘（通过模板变量实现）；提供指标探索与日志探索功能，支持临时查询、动态下钻以及分屏对比不同时间范围和数据源；内置告警规则定义与通知系统，可对接 Slack、PagerDuty 等工具；并支持在同一图表中混合使用不同数据源。该项目适用于需要统一监控、分析与告警的运维、开发及数据团队，以促进数据驱动的协作文化。




## 📋 工具动态速递

> 本周有发版或显著活跃的数据库工具，每条一句话。无动静的工具不在列。

- 🏷️ `2026.08.0` 🔥94c 📈+66 **[nocodb/nocodb](https://github.com/nocodb/nocodb)** — 🔥 🔥 🔥 A Free & Self-hostable Airtable Alternative（⭐ 64.5k）
- 🏷️ `v2.3.0` 🔥105c 📈+44 **[InsForge/InsForge](https://github.com/InsForge/InsForge)** — The all-in-one, open-source backend platform for agentic coding. InsForge gives your coding agent database, auth, storage, compute, hosting, and AI gateway to ship full-stack apps end-to-end.（⭐ 12.7k）
- 🏷️ `v0.28.0-beta.1` 🔥51c 📈+84 **[warp-tech/warpgate](https://github.com/warp-tech/warpgate)** — Fully transparent SSH, HTTPS, Kubernetes, MySQL and Postgres bastion/PAM that doesn't need additional client-side software（⭐ 7.5k）
- 🏷️ `v8.0.0-rc.1` 🔥43c 📈+17 **[prisma/prisma](https://github.com/prisma/prisma)** — Next-generation ORM for Node.js & TypeScript / PostgreSQL, MySQL, MariaDB, SQL Server, SQLite, MongoDB and CockroachDB（⭐ 47.6k）
- 🏷️ `4.0.2` 🔥46c 📈+11 **[pawelsalawa/letos](https://github.com/pawelsalawa/letos)** — A free, open source, multi-platform SQLite database manager.（⭐ 6.7k）
- 🏷️ `v7.2.5-premium-beta.2` 🔥39c 📈+9 **[dbgate/dbgate](https://github.com/dbgate/dbgate)** — Database manager for MySQL, PostgreSQL, SQL Server, MongoDB, SQLite and others. Runs under Windows, Linux, Mac or as web application（⭐ 7.2k）
- 🏷️ `v2.58.0` 🔥44c **[smartcontractkit/chainlink](https://github.com/smartcontractkit/chainlink)** — node of the decentralized oracle network, bridging on and off-chain computation（⭐ 8.2k）
- 🏷️ `v3.1.0` 🔥30c 📈+14 **[HelixDB/helix-db](https://github.com/HelixDB/helix-db)** — HelixDB is an OLTP graph-vector database built in Rust on Object Storage.（⭐ 5.7k）



## 🆕 新生项目

> 30 天内创建 + star ≥ 3，经相关性过滤。潜力榜已发酵，新星榜为早期观察。

### 🌟 潜力榜（star ≥ 30，已发酵）

| 项目 | 作用 | Star | 创建日 |
|---|---|---:|---|
| [albertoarena/laravel-truss](https://github.com/albertoarena/laravel-truss) | A live database structure viewer for Laravel that renders your schema as a scrollable, zoomable ER diagram. Structure only, never data. | 100 | 2026-07-22 |
| [FROWNINGdev/django-orm-lens](https://github.com/FROWNINGdev/django-orm-lens) | Free, MIT alternative to paid Django schema review. Blast radius on every PR, schema drift, N+1 across functions, ER diagrams, MCP server. No DB, no Django boot, no Pro tier. | 60 | 2026-07-12 |
| [indhifarhandika/LunarDump](https://github.com/indhifarhandika/LunarDump) | A lightweight, zero-trust CLI tool built in Python to automate, encrypt, and stream database backups directly to multi-cloud storage. | 38 | 2026-07-29 |
| [autumoswitzerland/Webduck](https://github.com/autumoswitzerland/Webduck) | A self-hosted DuckDB-as-a-Service server with REST API and Web UI. | 32 | 2026-07-24 |
| [MrXujiang/opne-aureka](https://github.com/MrXujiang/opne-aureka) | Upload spreadsheets, ask questions via chat, and auto-generate chart reports. No coding required, gain instant insights and unlock data value effortlessly. ｜上传表格，像聊天一样提问，系统自动分析生成图表报告。无需编程，即时洞察，数据价值触手可及。 | 30 | 2026-07-31 |

### 🆕 新星榜（star 3 ~ 30，早期观察）

> 📌 本档为早期观察信号，仅作记录，不代表成熟可用。

| 项目 | 作用 | Star |
|---|---|---:|
| [h5i-dev/h5i-db](https://github.com/h5i-dev/h5i-db) | An agent-native workspace for quantitative research: an in-terminal notebook, a high-performance time-series database, and a high-throughput backtesting engine. Written in Rust. | 28 |
| [kamranata/queue-sql](https://github.com/kamranata/queue-sql) | Queue any Laravel write query (delete/update/insert) across parallel batched jobs. | 28 |
| [Dicklesworthstone/frankengraphdb](https://github.com/Dicklesworthstone/frankengraphdb) | A blank-slate, memory-safe, ultra-high-performance property-graph database in Rust — unified MVCC/time-travel/branches/replication over a fountain-coded commit stream, WCO+factorized execution, incremental everything, and deterministic auditable results. | 20 |
| [hstptcn5/Catena](https://github.com/hstptcn5/Catena) | Catena exposes any SQLite database as a secure HTTP + WebSocket API in one small Go binary. | 14 |
| [ridi-oss/proxy-monster](https://github.com/ridi-oss/proxy-monster) | Self-hosted database access-control proxy for MySQL and PostgreSQL: lineage-aware column masking, Cedar policy, fail-closed deny, tamper-evident audit trail. | 14 |



## 📊 Top 总榜

> 数据库工具按 star 降序。数据库内核（PostgreSQL/MySQL/Redis 等）不在此列，请关注各厂商官方渠道。

| 排名 | 项目 | Star | 作用 |
|:--:|---|---:|---|
| 1 | [grafana/grafana](https://github.com/grafana/grafana) | 76.2k | The open and composable observability and data visualization platform. Visualize metrics, logs, and traces from multiple sources like Prometheus, Loki, Elasticsearch, InfluxDB, Postgres and many more. |
| 2 | [nocodb/nocodb](https://github.com/nocodb/nocodb) | 64.5k | 🔥 🔥 🔥 A Free & Self-hostable Airtable Alternative |
| 3 | [dbeaver/dbeaver](https://github.com/dbeaver/dbeaver) | 51.4k | Free universal database tool and SQL client |
| 4 | [prisma/prisma](https://github.com/prisma/prisma) | 47.6k | Next-generation ORM for Node.js & TypeScript / PostgreSQL, MySQL, MariaDB, SQL Server, SQLite, MongoDB and CockroachDB |
| 5 | [fastapi/full-stack-fastapi-template](https://github.com/fastapi/full-stack-fastapi-template) | 44.7k | Full stack, modern web application template. Using FastAPI, React, SQLModel, PostgreSQL, Docker, GitHub Actions, automatic HTTPS and more. |
| 6 | [drawdb-io/drawdb](https://github.com/drawdb-io/drawdb) | 38.7k | Free, simple, and intuitive online database diagram editor and SQL generator. |
| 7 | [sqlmapproject/sqlmap](https://github.com/sqlmapproject/sqlmap) | 38.1k | Automatic SQL injection and database takeover tool |
| 8 | [typeorm/typeorm](https://github.com/typeorm/typeorm) | 36.6k | TypeScript & JavaScript ORM for Node.js — supports PostgreSQL, MySQL, MariaDB, SQLite, SQL Server, Oracle, and more. |
| 9 | [sequelize/sequelize](https://github.com/sequelize/sequelize) | 30.4k | Feature-rich ORM for modern Node.js and TypeScript, it supports PostgreSQL (with JSON and JSONB support), MySQL, MariaDB, SQLite, MS SQL Server, Snowflake, Oracle DB, DB2 and DB2 for IBM i. |
| 10 | [chroma-core/chroma](https://github.com/chroma-core/chroma) | 29.0k | Search infrastructure for AI |

📎 来源:[GitHub API](https://api.github.com)



## ⚖️ License 雷达

> License 变更可能影响商用，是选型关键信号。

本期无 license 变更事件。



## 📌 关于本报告

**📊 统计口径**
- 数据来自 GitHub 公开 API，截至 2026-08-10
- 仅含数据库**工具**类项目；内核库（PG/MySQL/TiDB 等）版本请关注厂商官方渠道
- "新生项目" = 30 天内创建且 star ≥ 3；"活跃度" = 近 7 日 commit 数

**📎 数据说明**
- Search API 存在索引延迟，新建项目可能滞后数天被索引
- 编辑点评基于项目 release notes 与 README，信息以各项目官方为准

**📂 配套阅读**
- 本期 [**运维工具合辑周报**](https://mp.weixin.qq.com/)：6 类工具本周动态体检、新晋工具、静默观察、类目趋势（发布后替换为链接）


---

**🗂️ 往期回顾 ｜ 👍 点赞 + 在看 ｜ 🔔 关注「数据库开源周报」**
