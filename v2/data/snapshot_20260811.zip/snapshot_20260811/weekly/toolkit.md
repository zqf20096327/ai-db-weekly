> **数据库运维工具合辑 · 第 N 期**
> 每周一次，6 类数据库工具的动态体检。
> _2026-08-11_

> 📌 配套阅读：本期 [**主周报**](https://mp.weixin.qq.com/)（含精选解读、新生项目、Top 总榜）
> 📌 **数据边界**：本报告聚焦数据库**工具与生态**。数据库内核（PostgreSQL/MySQL/TiDB 等）的版本与发版请以各厂商官方渠道为准。

---


## ✏️ 本期导语

本周 29 个标杆工具中 **21 个有动态**（发版/活跃/涨星），8 个静默。管理客户端类最活跃（6 个有动态）；连接池 / 代理类整体偏静默（3 个静默）。此外，23 个本周高热度工具此前不在标杆清单，本期起纳入观察。



## 🩺 六类工具体检

> 每类按「有动态 → 静默」排列。🏷️发版 / 🔥活跃(commit) / 📈涨星。

### 连接池 / 代理 — 本周 4 动态 / 3 静默

| 项目 | Star | 本周变化 | 状态 | 作用 |
|---|---:|---|---|---|
| [vitessio/vitess](https://github.com/vitessio/vitess) | 21.2k | 🔥9c 📈+17 | 活跃 | Vitess is a database clustering system for horizontal scaling of MySQL. |
| [pgdogdev/pgdog](https://github.com/pgdogdev/pgdog) | 5.4k | 🔥18c 📈+16 | 活跃 | PostgreSQL connection pooler, load balancer and database sharder. |
| [pgbouncer/pgbouncer](https://github.com/pgbouncer/pgbouncer) | 4.3k | 🔥21c 📈+11 | 活跃 | lightweight connection pooler for PostgreSQL |
| [yandex/odyssey](https://github.com/yandex/odyssey) | 3.6k | 🔥13c | 活跃 | Scalable PostgreSQL connection pooler |
| [flike/kingshard](https://github.com/flike/kingshard) | 6.4k | — 静默 | 静默 | A high-performance MySQL proxy |
| [postgresml/pgcat](https://github.com/postgresml/pgcat) | 4.0k | — 静默 | 静默 | PostgreSQL pooler with sharding, load balancing and failover support. |
| [XiaoMi/Gaea](https://github.com/XiaoMi/Gaea) | 2.8k | — 静默 | 静默 | Gaea is a mysql proxy, it's developed by xiaomi b2c-dev team. |

### 高可用 / 容灾 — 本周 1 动态 / 3 静默

| 项目 | Star | 本周变化 | 状态 | 作用 |
|---|---:|---|---|---|
| [patroni/patroni](https://github.com/patroni/patroni) | 8.7k | 🔥3c 📈+11 | 活跃 | A template for PostgreSQL High Availability with Etcd, Consul, ZooKeeper, or Kubernetes |
| [zalando/postgres-operator](https://github.com/zalando/postgres-operator) | 5.2k | — 静默 | 静默 | Postgres operator creates and manages PostgreSQL clusters running in Kubernetes |
| [sorintlab/stolon](https://github.com/sorintlab/stolon) | 4.8k | — 静默 | 静默 | PostgreSQL cloud native High Availability and more. |
| [reactive-tech/kubegres](https://github.com/reactive-tech/kubegres) | 1.4k | — 静默 | 静默 | Kubegres is a Kubernetes operator allowing to deploy one or many clusters of PostgreSql instances and manage databases replication, failover and backup. |

### 迁移 / 变更 — 本周 4 动态 / 1 静默

| 项目 | Star | 本周变化 | 状态 | 作用 |
|---|---:|---|---|---|
| [golang-migrate/migrate](https://github.com/golang-migrate/migrate) | 18.8k | 📈+23 | 涨星 | Database migrations. CLI and Golang library. |
| [github/gh-ost](https://github.com/github/gh-ost) | 13.5k | 🔥5c 📈+6 | 活跃 | GitHub's Online Schema-migration Tool for MySQL |
| [flyway/flyway](https://github.com/flyway/flyway) | 10.0k | 🏷️flyway-13.2.0 🔥1c 📈+15 | 发版 | Flyway by Redgate • Database Migrations Made Easy. |
| [sqldef/sqldef](https://github.com/sqldef/sqldef) | 3.1k | 🔥8c | 活跃 | Idempotent schema management for MySQL, PostgreSQL, SQLite, and SQL Server |
| [xataio/pgroll](https://github.com/xataio/pgroll) | 6.5k | — 静默 | 静默 | PostgreSQL zero-downtime migrations made easy |

### 备份 / 恢复 — 本周 3 动态 / 1 静默

| 项目 | Star | 本周变化 | 状态 | 作用 |
|---|---:|---|---|---|
| [databasus/databasus](https://github.com/databasus/databasus) | 7.9k | 📈+39 | 涨星 | PostgreSQL backup tool with Point-In-Time-Recovery and restore verification |
| [David-Crty/databasement](https://github.com/David-Crty/databasement) | 1.9k | 🔥9c 📈+61 | 活跃 | Self-hosted database backup manager with a web UI. Schedule, backup, and restore MySQL, PostgreSQL, MariaDB, Microsoft SQL Server, MongoDB, SQLite & Redis to S3, SFTP, Samba or local storage. SSH Tunnel support. |
| [Aiven-Open/pghoard](https://github.com/Aiven-Open/pghoard) | 1.4k | 🔥2c | 活跃 | PostgreSQL® backup and restore service |
| [EnterpriseDB/barman](https://github.com/EnterpriseDB/barman) | 3.2k | — 静默 | 静默 | Barman - Backup and Recovery Manager for PostgreSQL |

### 监控 / 诊断 — 本周 3 动态 / 0 静默

| 项目 | Star | 本周变化 | 状态 | 作用 |
|---|---:|---|---|---|
| [grafana/grafana](https://github.com/grafana/grafana) | 76.2k | 🏷️v13.0.6 🔥208c 📈+122 | 发版 | The open and composable observability and data visualization platform. Visualize metrics, logs, and traces from multiple sources like Prometheus, Loki, Elasticsearch, InfluxDB, Postgres and many more. |
| [VictoriaMetrics/VictoriaMetrics](https://github.com/VictoriaMetrics/VictoriaMetrics) | 17.5k | 🏷️v1.149.0 🔥14c 📈+42 | 发版 | VictoriaMetrics: fast, cost-effective monitoring solution and time series database |
| [erikdarlingdata/PerformanceMonitor](https://github.com/erikdarlingdata/PerformanceMonitor) | 469 | 🔥101c 📈+7 | 活跃 | Free, open-source SQL Server performance monitoring — 32 collectors, real-time alerts, graphical plan viewer, MCP server for AI analysis. Supports SQL 2016-2025, Azure SQL, AWS RDS. |

### 管理客户端 — 本周 6 动态 / 0 静默

| 项目 | Star | 本周变化 | 状态 | 作用 |
|---|---:|---|---|---|
| [dbeaver/dbeaver](https://github.com/dbeaver/dbeaver) | 51.4k | 🔥31c 📈+90 | 活跃 | Free universal database tool and SQL client |
| [sqlitebrowser/sqlitebrowser](https://github.com/sqlitebrowser/sqlitebrowser) | 24.4k | 🏷️nightly 🔥3c 📈+21 | 发版 | Official home of the DB Browser for SQLite (DB4S) project. Previously known as "SQLite Database Browser" and "Database Browser for SQLite". Website at: |
| [beekeeper-studio/beekeeper-studio](https://github.com/beekeeper-studio/beekeeper-studio) | 23.3k | 🔥101c 📈+31 | 活跃 | Modern and easy to use SQL client for MySQL, Postgres, SQLite, SQL Server, and more. Linux, MacOS, and Windows. |
| [chartdb/chartdb](https://github.com/chartdb/chartdb) | 22.7k | 📈+26 | 涨星 | Database diagrams editor that allows you to visualize and design your DB with a single query. |
| [sosedoff/pgweb](https://github.com/sosedoff/pgweb) | 9.5k | 📈+10 | 涨星 | Cross-platform client for PostgreSQL databases |
| [dbgate/dbgate](https://github.com/dbgate/dbgate) | 7.2k | 🏷️v7.2.5-premium-beta.3 🔥51c 📈+13 | 发版 | Database manager for MySQL, PostgreSQL, SQL Server, MongoDB, SQLite and others. Runs under Windows, Linux, Mac or as web application |



## 🆕 本周新晋工具

> 不在标杆清单、但本周发版或高涨幅的工具，纳入观察。

| 项目 | Star | 本周变化 | 归类 | 作用 |
|---|---:|---|---|---|
| [drawdb-io/drawdb](https://github.com/drawdb-io/drawdb) | 38.8k | 🔥7c 📈+545 | 其他 | Free, simple, and intuitive online database diagram editor and SQL generator.（深度解读见主周报） |
| [chroma-core/chroma](https://github.com/chroma-core/chroma) | 29.0k | 🔥2c 📈+57 | AI 工具 | Search infrastructure for AI |
| [OtterMind/Chat2DB](https://github.com/OtterMind/Chat2DB) | 27.9k | 🏷️v5.3.3 🔥63c 📈+289 | 管理客户端 | 🔥🔥🔥 AI-driven database tool and SQL client, The hottest GUI client, supporting MySQL, Oracle, PostgreSQL, DB2, SQL Server, DB2, SQLite, H2, ClickHouse, and more.（深度解读见主周报） |
| [Canner/WrenAI](https://github.com/Canner/WrenAI) | 17.2k | 🏷️wren-semantic-core-v0.3.1 🔥11c 📈+348 | AI 工具 | GenBI (Generative BI) for AI agents, an open-source, governed text-to-SQL through an open context layer that turns natural-language questions into trusted dashboards, charts, and SQL across 20+ data sources, such as BigQuery, Snowflake, PostgreSQL, ClickHouse, Amazon Redshift, Databricks and more.（深度解读见主周报） |
| [smartcontractkit/chainlink](https://github.com/smartcontractkit/chainlink) | 8.2k | 🏷️v2.59.0 🔥49c | 其他 | node of the decentralized oracle network, bridging on and off-chain computation |
| [turbot/steampipe](https://github.com/turbot/steampipe) | 7.9k | 🏷️v2.4.5 🔥3c | 其他 | Zero-ETL, infinite possibilities. Live query APIs, code & more with SQL. No DB required. |
| [supabase/realtime](https://github.com/supabase/realtime) | 7.6k | 🏷️v2.124.3 🔥19c | 其他 | Broadcast, Presence, and Postgres Changes via WebSockets |
| [warp-tech/warpgate](https://github.com/warp-tech/warpgate) | 7.6k | 🏷️v0.28.0-beta.1 🔥46c 📈+100 | 连接池/代理 | Fully transparent SSH, HTTPS, Kubernetes, MySQL and Postgres bastion/PAM that doesn't need additional client-side software（深度解读见主周报） |



## 😴 静默观察

> 本周无发版、无 commit、无涨星的标杆工具。持续静默可能意味着维护放缓，选型时留意。

**连接池 / 代理**：flike/kingshard · postgresml/pgcat · XiaoMi/Gaea
**高可用 / 容灾**：zalando/postgres-operator · sorintlab/stolon · reactive-tech/kubegres
**迁移 / 变更**：xataio/pgroll
**备份 / 恢复**：EnterpriseDB/barman

> 📊 本周静默率 8/29（28%）。
连接池 / 代理类静默率最高（3/7）。



## 📊 类目趋势速览

| 类目 | 工具数 | 本周动态 | 静默 | 类目 star 净增 |
|---|:--:|:--:|:--:|---:|
| 连接池 / 代理 | 7 | 4 | 3 | +49 |
| 高可用 / 容灾 | 4 | 1 | 3 | +17 |
| 迁移 / 变更 | 5 | 4 | 1 | +47 |
| 备份 / 恢复 | 4 | 3 | 1 | +104 |
| 监控 / 诊断 | 3 | 3 | 0 | +171 |
| 管理客户端 | 6 | 6 | 0 | +191 |
| **合计** | **29** | **21** | **8** | **+579** |



## 📌 关于本期

**📊 统计口径**
- 数据来自 GitHub 公开 API，截至 2026-08-11
- "动态" = 本周有发版（🏷️）/ 近 7 日有 commit（🔥）/ star 净增 > 5（📈），任一满足即算
- "静默" = 以上三项均无
- 标杆清单每季度评审一次，增减工具；新晋工具每周动态纳入

**📎 相关阅读**
- 本期 [**主周报**](https://mp.weixin.qq.com/)：精选解读、新生项目、Top 总榜、License 雷达


---

**🗂️ 往期合辑 ｜ 👍 点赞 + 在看 ｜ 🔔 关注「数据库开源周报」**
