> **数据库开源周报 · 第 N 期**
> 每周 5 分钟，追踪数据库工具与生态的一手动态。
> _2026-08-11_

> 📌 **数据边界**：本报告聚焦数据库**工具与生态**。数据库内核（PostgreSQL/MySQL/TiDB 等）的版本与发版请以各厂商官方渠道为准。
> 📌 **配套阅读**：本期 [**运维工具合辑周报**](https://mp.weixin.qq.com/)（6 类工具本周动态体检）

---


## ✏️ 本期导语

本周 star 异常上涨（≥100）10 个：powercontext（+837）、write-you-a-vector-db（+783）、drawdb（+545）、WrenAI（+348）、Chat2DB（+289）。
新入榜工具 26 个。
本周 36 个工具发版。
无 License 变更。
详见下方各栏。


## 🔍 本周精选解读

### 1. WrenAI wren-semantic-core-v0.3.1

[Canner/WrenAI](https://github.com/Canner/WrenAI) · ⭐ 17.2k（+348） · [发版说明](https://github.com/Canner/WrenAI/releases/tag/wren-semantic-core-v0.3.1)

**发生了什么**：### 发生了什么

本周（2026-08-10）发布了 wren-semantic-core-v0.3.1 版本。本次发版包含一个核心修复：修复了 RLAC（行级访问控制）循环检测状态在每次分析器调用时未重置的问题。该修复通过将循环检测状态限定在单次分析器调用范围内，避免了状态在多次调用间残留可能导致的误判或逻辑错误。这是针对语义核心模块的稳定性修复，不涉及新功能或接口变更。

**为什么值得关注**：### 为什么值得关注

WrenAI 是一个开源的生成式商业智能（GenBI）引擎，面向 AI 代理（agent）场景，解决自然语言查询数据库时缺乏业务语义和治理约束的问题。其核心能力包括：通过开放上下文层和语义层（MDL）将自然语言问题转化为受治理的 SQL、图表和仪表盘；支持 22+ 数据源（如 BigQuery、Snowflake、PostgreSQL、ClickHouse 等）；提供可审查、版本化的业务定义管理（instructions.md、queries.yml）和记忆索引；支持将生成的仪表盘一键部署到 Vercel 或 Cloudflare Pages。该项目采用 Apache 2.0 开源协议，核心引擎基于 Apache DataFusion，并提供 Python SDK、CLI 和 MCP 服务器，适用于希望让 AI 代理在受控、可审计的环境下生成可信 BI 输出的开发者和数据团队。

### 2. Chat2DB v5.3.3

[OtterMind/Chat2DB](https://github.com/OtterMind/Chat2DB) · ⭐ 27.9k（+289） · [发版说明](https://github.com/OtterMind/Chat2DB/releases/tag/v5.3.3)

**发生了什么**：Chat2DB Community 5.3.3 于本周发布，主要聚焦桌面端工作区、集成终端和本地文件体验的改进。该版本新增了集成终端、本地文件预览、工作区分屏、可配置的 SQL 与数据库树快捷键、MiniMax 模型提供商支持，以及跨数据库方言的无条件标识符引用功能。此外，版本包含 95 项修复，涉及跨数据库的 SQL 与 DDL 安全转义、DML 与分页校验、存储一致性、结果网格、AI 流所有权、BI 图表、数据库兼容性以及 macOS 打包与启动问题。开发与发布工程方面，更新了 Community Web 与 JCEF 启动器、严格化发布元数据生成、桌面字节码验证，并引入了仅回环地址的受监管开发运行时。

**为什么值得关注**：Chat2DB 是一个 AI 驱动的跨平台数据库客户端和 SQL 工作区，面向开发者、DBA、分析师和数据团队。它支持 40 多种数据库（包括 MySQL、PostgreSQL、Oracle、SQL Server、ClickHouse、MongoDB、Redis 等），并提供完整的 SQL 编辑、补全、格式化、执行与历史记录功能。其核心特色是内置 AI 助手，允许用户连接自有模型，通过自然语言生成、解释和优化 SQL。工具还涵盖数据库元数据浏览、表与对象管理（DDL/DML）、就地数据编辑、数据导入导出、仪表盘与图表，以及支持 MCP 的开源 CLI。该工具定位为本地优先的单用户应用，强调数据安全，对存储的数据源密码和 AI API 密钥使用 AES-256-GCM 加密。

### 3. grafana v13.0.6

[grafana/grafana](https://github.com/grafana/grafana) · ⭐ 76.2k（+122） · [发版说明](https://github.com/grafana/grafana/releases/tag/v13.0.6)

**发生了什么**：grafana/grafana 本周发布了 v13.0.6 版本。该版本为维护性发版，主要包含针对上一版本（v13.0.x 系列）的缺陷修复与稳定性改进。具体变更内容需参考官方下载页面及“What's new”文档，其中列出了该补丁版本对应的更新说明与已知问题修复列表。

**为什么值得关注**：Grafana 是一个开源的可观测性与数据可视化平台，核心功能是连接多种数据源（如 Prometheus、Loki、Elasticsearch、InfluxDB、Postgres 等），并对其中的指标、日志和链路追踪数据进行查询、可视化与告警。它支持创建动态仪表盘（通过模板变量实现复用）、通过临时查询进行指标探索、在保留标签过滤条件的前提下从指标切换到日志分析，并允许在同一图表中混合不同数据源。此外，Grafana 提供可视化告警规则配置，可对接 Slack、PagerDuty 等通知系统，适用于需要统一监控视图和团队协作的数据驱动场景。项目采用 AGPL-3.0-only 许可证（含 Apache-2.0 例外条款）。




## 📋 工具动态速递

> 本周有发版或显著活跃的数据库工具，每条一句话。无动静的工具不在列。

- 🏷️ `v2.3.0` 🔥119c 📈+58 **[InsForge/InsForge](https://github.com/InsForge/InsForge)** — The all-in-one, open-source backend platform for agentic coding. InsForge gives your coding agent database, auth, storage, compute, hosting, and AI gateway to ship full-stack apps end-to-end.（⭐ 12.7k）
- 🏷️ `2026.08.0` 🔥96c 📈+73 **[nocodb/nocodb](https://github.com/nocodb/nocodb)** — 🔥 🔥 🔥 A Free & Self-hostable Airtable Alternative（⭐ 64.5k）
- 🏷️ `0.11.0` 🔥50c 📈+115 **[fastapi/full-stack-fastapi-template](https://github.com/fastapi/full-stack-fastapi-template)** — Full stack, modern web application template. Using FastAPI, React, SQLModel, PostgreSQL, Docker, GitHub Actions, automatic HTTPS and more.（⭐ 44.7k）
- 🏷️ `v0.28.0-beta.1` 🔥46c 📈+100 **[warp-tech/warpgate](https://github.com/warp-tech/warpgate)** — Fully transparent SSH, HTTPS, Kubernetes, MySQL and Postgres bastion/PAM that doesn't need additional client-side software（⭐ 7.6k）
- 🏷️ `4.0.2` 🔥82c 📈+12 **[pawelsalawa/letos](https://github.com/pawelsalawa/letos)** — A free, open source, multi-platform SQLite database manager.（⭐ 6.7k）
- 🏷️ `v7.2.5-premium-beta.3` 🔥51c 📈+13 **[dbgate/dbgate](https://github.com/dbgate/dbgate)** — Database manager for MySQL, PostgreSQL, SQL Server, MongoDB, SQLite and others. Runs under Windows, Linux, Mac or as web application（⭐ 7.2k）
- 🏷️ `v3.1.0` 🔥39c 📈+21 **[HelixDB/helix-db](https://github.com/HelixDB/helix-db)** — HelixDB is an OLTP graph-vector database built in Rust on Object Storage.（⭐ 5.7k）
- 🏷️ `v8.0.0-rc.1` 🔥32c 📈+19 **[prisma/prisma](https://github.com/prisma/prisma)** — Next-generation ORM for Node.js & TypeScript / PostgreSQL, MySQL, MariaDB, SQL Server, SQLite, MongoDB and CockroachDB（⭐ 47.6k）



## 🆕 新生项目

> 30 天内创建 + star ≥ 3，经相关性过滤。潜力榜已发酵，新星榜为早期观察。

### 🌟 潜力榜（star ≥ 30，已发酵）

| 项目 | 作用 | Star | 创建日 |
|---|---|---:|---|
| [albertoarena/laravel-truss](https://github.com/albertoarena/laravel-truss) | A live database structure viewer for Laravel that renders your schema as a scrollable, zoomable ER diagram. Structure only, never data. | 165 | 2026-07-22 |
| [indhifarhandika/LunarDump](https://github.com/indhifarhandika/LunarDump) | A lightweight, zero-trust CLI tool built in Python to automate, encrypt, and stream database backups directly to multi-cloud storage. | 38 | 2026-07-29 |
| [autumoswitzerland/Webduck](https://github.com/autumoswitzerland/Webduck) | A self-hosted DuckDB-as-a-Service server with REST API and Web UI. | 37 | 2026-07-24 |
| [MrXujiang/opne-aureka](https://github.com/MrXujiang/opne-aureka) | Upload spreadsheets, ask questions via chat, and auto-generate chart reports. No coding required, gain instant insights and unlock data value effortlessly. ｜上传表格，像聊天一样提问，系统自动分析生成图表报告。无需编程，即时洞察，数据价值触手可及。 | 30 | 2026-07-31 |
| [tnandla/portfolio-os](https://github.com/tnandla/portfolio-os) | Self-hosted operations app for teams running a portfolio of websites: projects, an encrypted credential vault, content work, people and money. Laravel + Livewire, runs on PHP/MySQL shared hosting. | 59 | 2026-08-05 |

### 🆕 新星榜（star 3 ~ 30，早期观察）

> 📌 本档为早期观察信号，仅作记录，不代表成熟可用。

| 项目 | 作用 | Star |
|---|---|---:|
| [h5i-dev/h5i-db](https://github.com/h5i-dev/h5i-db) | An agent-native workspace for quantitative research: an in-terminal notebook, a high-performance time-series database, and a high-throughput backtesting engine. Written in Rust. | 28 |
| [Dicklesworthstone/frankengraphdb](https://github.com/Dicklesworthstone/frankengraphdb) | A blank-slate, memory-safe, ultra-high-performance property-graph database in Rust — unified MVCC/time-travel/branches/replication over a fountain-coded commit stream, WCO+factorized execution, incremental everything, and deterministic auditable results. | 20 |
| [hstptcn5/Catena](https://github.com/hstptcn5/Catena) | Catena exposes any SQLite database as a secure HTTP + WebSocket API in one small Go binary. | 14 |
| [ridi-oss/proxy-monster](https://github.com/ridi-oss/proxy-monster) | Self-hosted database access-control proxy for MySQL and PostgreSQL: lineage-aware column masking, Cedar policy, fail-closed deny, tamper-evident audit trail. | 14 |
| [backenly/backenly](https://github.com/backenly/backenly) | Autonomous backend platform. Your coding agent builds it over MCP, Backenly keeps it running: Postgres, REST APIs, auth, storage, realtime, and functions, with every change governed, verified, and reversible. | 14 |



## 📊 Top 总榜

> 数据库工具按 star 降序。数据库内核（PostgreSQL/MySQL/Redis 等）不在此列，请关注各厂商官方渠道。

| 排名 | 项目 | Star | 作用 |
|:--:|---|---:|---|
| 1 | [grafana/grafana](https://github.com/grafana/grafana) | 76.2k | The open and composable observability and data visualization platform. Visualize metrics, logs, and traces from multiple sources like Prometheus, Loki, Elasticsearch, InfluxDB, Postgres and many more. |
| 2 | [nocodb/nocodb](https://github.com/nocodb/nocodb) | 64.5k | 🔥 🔥 🔥 A Free & Self-hostable Airtable Alternative |
| 3 | [dbeaver/dbeaver](https://github.com/dbeaver/dbeaver) | 51.4k | Free universal database tool and SQL client |
| 4 | [prisma/prisma](https://github.com/prisma/prisma) | 47.6k | Next-generation ORM for Node.js & TypeScript / PostgreSQL, MySQL, MariaDB, SQL Server, SQLite, MongoDB and CockroachDB |
| 5 | [fastapi/full-stack-fastapi-template](https://github.com/fastapi/full-stack-fastapi-template) | 44.7k | Full stack, modern web application template. Using FastAPI, React, SQLModel, PostgreSQL, Docker, GitHub Actions, automatic HTTPS and more. |
| 6 | [drawdb-io/drawdb](https://github.com/drawdb-io/drawdb) | 38.8k | Free, simple, and intuitive online database diagram editor and SQL generator. |
| 7 | [sqlmapproject/sqlmap](https://github.com/sqlmapproject/sqlmap) | 38.2k | Automatic SQL injection and database takeover tool |
| 8 | [typeorm/typeorm](https://github.com/typeorm/typeorm) | 36.6k | TypeScript & JavaScript ORM for Node.js — supports PostgreSQL, MySQL, MariaDB, SQLite, SQL Server, Oracle, and more. |
| 9 | [sequelize/sequelize](https://github.com/sequelize/sequelize) | 30.4k | Feature-rich ORM for modern Node.js and TypeScript, it supports PostgreSQL (with JSON and JSONB support), MySQL, MariaDB, SQLite, MS SQL Server, Snowflake, Oracle DB, DB2 and DB2 for IBM i. |
| 10 | [chroma-core/chroma](https://github.com/chroma-core/chroma) | 29.0k | Search infrastructure for AI |

📎 来源:[GitHub API](https://api.github.com)



## ⚖️ License 雷达

> License 变更可能影响商用，是选型关键信号。

本期无 license 变更事件。



## 📌 关于本报告

**📊 统计口径**
- 数据来自 GitHub 公开 API，截至 2026-08-11
- 仅含数据库**工具**类项目；内核库（PG/MySQL/TiDB 等）版本请关注厂商官方渠道
- "新生项目" = 30 天内创建且 star ≥ 3；"活跃度" = 近 7 日 commit 数

**📎 数据说明**
- Search API 存在索引延迟，新建项目可能滞后数天被索引
- 编辑点评基于项目 release notes 与 README，信息以各项目官方为准

**📂 配套阅读**
- 本期 [**运维工具合辑周报**](https://mp.weixin.qq.com/)：6 类工具本周动态体检、新晋工具、静默观察、类目趋势（发布后替换为链接）


---

**🗂️ 往期回顾 ｜ 👍 点赞 + 在看 ｜ 🔔 关注「数据库开源周报」**
