# 📋 数据库开源生态周报 · 第 N 期

> 📌 **数据源**：GitHub。聚焦开源工具与实验项目，不涉及厂商内核信息。生产可用性请自行评估。

> _2026-08-13_

---

## 📌 本周 DBA 速览

- 🗄️ **国外数据库**：[drawdb](https://github.com/drawdb-io/drawdb)（+450）—— Free, simple, and intuitive online database diagram editor a
- 🇨🇳 **国产数据库**：[powercontext](https://github.com/oceanbase/powercontext)（+857）—— PowerContext: The Next Generation of PowerMem.
- 🤖 **AI工具**：[WrenAI](https://github.com/Canner/WrenAI)（+67）—— GenBI (Generative BI) for AI agents, an open-source, governe



## 🗄️ 板块一 · 国外数据库
> 聚焦国外开源数据库管理、运维、开发工具及实验性引擎。

### 🔥 活跃榜 Top3

| 项目 | 分类 | 适用数据库 | 增长 | 项目描述 | 🤖 AI 解读 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **[drawdb-io/drawdb](https://github.com/drawdb-io/drawdb)** | 其他 | PostgreSQL / Oracle / SQLite / MariaDB | **+450** | Free, simple, and intuitive online database diagram editor and SQL generator. | 今日可试：drawDB在线ERD工具，免登录即可绘制数据库关系图并生成PostgreSQL/Oracle/SQLite/MariaDB的SQL脚本，适合快速梳理表结构或生成迁移脚本。建议用现有库反向建模验证其SQL准确性，再决定是否纳入日常设计流程。 |
| **[WowoEngine/SawitDB](https://github.com/WowoEngine/SawitDB)** | 其他 | 待确认 | **+185** | SawitDB: The First Agricultural-Based Database with Anti-Corruption Protocols. B | **收藏观察：** SawitDB是面向数据主权的实验性嵌入式数据库，用印尼语农业术语替代SQL（AQL），采用4KB分页+对象缓存混合架构，支持WAL崩溃恢复。若需轻量单文件存储且接受非标准查询语法，可关注其NPM包及Go版本进展。 |
| **[heywinit/discodb](https://github.com/heywinit/discodb)** | 平台 | 不适用（数据库本身） | **+151** | relational database stored in discord guilds | 收藏观察：将Discord消息、频道映射为行存储与段文件，实现PostgreSQL协议兼容的日志型关系库。建议DBA关注其WAL与MVCC实现，但勿用于生产，可作分布式存储边界压力测试参考。 |

### 🔍 本周解读 · drawdb

> Free, simple, and intuitive online database diagram editor and SQL generator.

| 维度 | 说明 |
| :--- | :--- |
| **项目** | **[drawdb-io/drawdb](https://github.com/drawdb-io/drawdb)**（⭐ 39.0k，本周 +450 · 分类 其他 · 适用 PostgreSQL / Oracle / SQLite / MariaDB） |
| **解决了什么** | drawDB解决了数据库设计过程中缺乏免费、轻量、可视化ERD编辑工具的问题，让用户无需注册或安装即可在浏览器中完成数据库表结构设计、关系建模，并一键生成标准SQL脚本，极大降低了数据库建模的门槛。 |
| **核心亮点** | 纯前端浏览器运行、零后端依赖（可选共享服务）   可视化拖拽式ERD编辑，支持PostgreSQL、Oracle、SQLite、MariaDB多方言   一键导出/导入SQL脚本，自动生成建表语句与迁移脚本   支持Docker本地部署，数据隐私可控   开源免费，社区活跃（Discord、X），支持自定义扩展 |
| **适用场景** | 快速原型设计：产品初期用可视化方式梳理业务表结构与关系   教学培训：向学员直观演示数据库范式设计、外键约束等概念   跨团队协作：通过导出SQL脚本或截图，在开发、测试、DBA间传递表结构变更   轻量级替代品：作为Navicat、PowerDesigner等重型工具的免费补充，用于临时或小型项目建模 |
| **🛑 DBA 行动指南** | 1. 本地快速试用：执行 `git clone https://github.com/drawdb-io/drawdb && cd drawdb && npm install && npm run dev`，浏览器访问 `http://localhost:5173`   2. 生产环境部署：使用 `docker build -t drawdb . && docker run -p 3000:80 drawdb`，将服务暴露到内网供团队使用   3. 验证SQL生成质量：在drawDB中建一张含主键、外键、索引的表，导出SQL后与目标库（如PostgreSQL）的 `pg_dump --schema-only` 输出对比，确认类型映射和约束语法正确   4. 启用共享功能（可选）：部署 [drawdb-server](https://github.com/drawdb-io/drawdb-server)，按 `.env.sample` 配置环境变量，实现团队间在线分享ERD   5. 纳入日常变更流程：每次表结构变更前，先在drawDB中更新ERD并导出迁移SQL，评审通过后再执行到测试库，确保文档与库结构同步 |



## 🇨🇳 板块二 · 国产数据库
> 聚焦在 GitHub 上活跃的国产开源数据库生态项目（内核以各厂商官方为准）。

### 🔥 活跃榜 Top3

| 项目 | 分类 | 适用数据库 | 增长 | 项目描述 | 🤖 AI 解读 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **[oceanbase/powercontext](https://github.com/oceanbase/powercontext)** | 其他 | 待确认 | **+857** | PowerContext: The Next Generation of PowerMem. | 今日可试：用PowerContext为DBA的运维脚本和故障排查记录提供持久化上下文，跨会话恢复决策与状态，减少重复分析。建议安装后运行`powercontext doctor`验证环境，并在Codex中启用插件，将SQL调优结论存入项目记忆。 |
| **[bytebase/bytebase](https://github.com/bytebase/bytebase)** | 管理 | PostgreSQL / MySQL / Oracle / SQL Server / MongoDB | **+14** | Database governance built for humans and agents — controlling changes and access | Bytebase为DBA提供统一数据库治理控制平面，整合变更管理、访问控制与合规审计，替代散落的脚本、客户端和工单工具。今日可试：部署社区版，连接测试库，体验SQL审核规则与GitOps变更流程，对比现有工具体系评估落地价值。 |
| **[ClouGence/open-cdm](https://github.com/ClouGence/open-cdm)** | 管理 | 6+种数据库（PostgreSQL / MySQL / Oracle等） | **+11** | A free and open-source database management tool, suitable for team use. It offer | CloudDM为DBA提供团队级数据库管理平台，整合权限控制、数据脱敏、SQL审计与CI/CD，支持跨地域部署。本周可做：部署其K8s集群版，接入MySQL与PostgreSQL，配置脱敏策略并试点SQL审计流程，以替代多工具分散管理。 |

### 🌱 新锐发现

| 项目 | 分类 | 适用数据库 | 增长 | 项目描述 | 🤖 AI 解读 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **[opengauss-mirror/openGauss](https://github.com/opengauss-mirror/openGauss)** | 其他 | 待确认 | — |  | 收藏观察：openGauss-mirror/openGauss为openGauss官方镜像仓库，便于DBA获取源码、版本对比及社区动态。建议关注其release分支与补丁更新，用于评估迁移或升级路径，暂无需部署。 |
| **[opengauss-mirror/openGauss-MemoryWorkload](https://github.com/opengauss-mirror/openGauss-MemoryWorkload)** | 其他 | 待确认 | — |  | 收藏观察：该项目聚焦openGauss内存工作负载分析，可能用于诊断内存争用或优化缓存策略。建议关注其是否提供内存视图或调优工具，待确认数据库版本兼容性后，再评估是否引入生产环境。 |

### 🔍 本周解读 · powercontext

> PowerContext: The Next Generation of PowerMem.

| 维度 | 说明 |
| :--- | :--- |
| **项目** | **[oceanbase/powercontext](https://github.com/oceanbase/powercontext)**（⭐ 857，本周 +857 · 分类 其他 · 适用 待确认） |
| **解决了什么** | 解决AI智能体在跨会话协作中缺乏持久化、项目级上下文记忆的问题，使后续会话无需依赖聊天历史即可恢复决策、结果、当前状态或下一步计划，避免重复推理与状态丢失。 |
| **核心亮点** | - 本地Server + SQLite存储，提供持久化、项目级作用域的上下文管理 - 异步Python客户端、Core SDK、CLI及Codex插件，多接口覆盖（含HTTP与MCP） - 支持显式记忆、修订、退役操作，可恢复决策/结果/状态/下一步 - 在LOCOMO基准上准确率达90.78%（较PowerMem提升3%），搜索p95延迟仅1.38秒 - 安装即用，无需克隆仓库，通过Git URL直接安装并配置Codex插件 |
| **适用场景** | - AI编码助手（如Codex）跨会话项目记忆恢复与状态追踪 - 多智能体协作系统中共享决策与进展记录 - 需要持久化上下文的长周期开发任务或复杂调试流程 - 非Python进程或外部Agent宿主通过HTTP/MCP集成记忆服务 |
| **🛑 DBA 行动指南** | 1. 安装与配置（需读权限）：`uv tool install "powercontext[cli,server] @ git+https://github.com/oceanbase/powercontext.git@master"` 然后执行 `powercontext setup codex --source oceanbase/powercontext --ref master` 2. 启动服务并诊断：终端运行 `powercontext server run`，另开终端执行 `powercontext doctor` 和 `powercontext doctor codex` 验证依赖与集成状态 3. 若需Python项目集成，按角色添加依赖：`uv add "powercontext[client] @ git+https://github.com/oceanbase/powercontext.git@master"`（可选extras：builtin、client、server、cli） 4. 数据库层面：默认SQLite持久化无需配置，但建议监控Server健康状态——运行时或数据库故障会使Server不可用，推理失败仅降级不影响流量 5. 开发贡献时：运行 `make install` 安装锁定环境，提交PR前执行 `make test`、`make check`、`make docs-test` 确保质量 |



## 🤖 板块三 · AI 工具
> 聚焦与 DBA 日常工作直接相关的 AI 辅助工具（text2sql / AI DBA / DB-MCP 等）。

### 🔥 活跃榜 Top3

| 项目 | 分类 | 适用数据库 | 增长 | 项目描述 | 🤖 AI 解读 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **[Canner/WrenAI](https://github.com/Canner/WrenAI)** | 平台 | PostgreSQL / ClickHouse | **+67** | GenBI (Generative BI) for AI agents, an open-source, governed text-to-SQL throug | **一句话价值**：WrenAI为DBA提供受治理的Text-to-SQL层，让AI Agent安全查询PostgreSQL/ClickHouse等20+数据源，自动生成仪表盘，减少临时取数压力。  **本周可做**：部署WrenAI连接测试库，配置语义层（业务术语映射），对比其生成的SQL与手写SQL的执行计划，评估 |
| **[chroma-core/chroma](https://github.com/chroma-core/chroma)** | 其他 | 待确认 | **+61** | Search infrastructure for AI | **对DBA的价值**：Chroma是面向AI应用的嵌入式向量数据库，可简化RAG/语义搜索的存储与检索，减少自建向量索引的运维成本。  **今日可试**：`pip install chromadb`，用Python创建内存集合并写入文档，体验其自动分块、嵌入与向量检索的4函数API，对比传统SQL的相似度查询差异。 |
| **[bytebase/dbhub](https://github.com/bytebase/dbhub)** | 管理 | PostgreSQL / MySQL / SQLite / SQL Server / MariaDB | **+41** | Token conscious database MCP server for Postgres, MySQL, SQL Server, MariaDB, SQ | DBHub将数据库操作封装为MCP服务，让AI助手直接查询PostgreSQL、MySQL等库，DBA可借此实现自然语言运维。今日可试：用Claude Desktop连接DBHub，执行`SELECT`验证AI读库能力，再逐步开放写权限。 |

### 🔍 本周解读 · WrenAI

> GenBI (Generative BI) for AI agents, an open-source, governed text-to-SQL through an open context layer that turns natur

| 维度 | 说明 |
| :--- | :--- |
| **项目** | **[Canner/WrenAI](https://github.com/Canner/WrenAI)**（⭐ 17.3k，本周 +67 · 分类 平台 · 适用 PostgreSQL / ClickHouse） |
| **解决了什么** | WrenAI 解决了传统 Text-to-SQL 方案中“语义缺失”与“治理失控”的核心矛盾——它通过一个开放的 AI 上下文层（AI Context Layer）和受治理的语义层（MDL），让 AI 代理在 22+ 数据源（含 PostgreSQL、ClickHouse）上生成可信的 SQL、图表和仪表盘，避免模型“自信地胡说八道”，同时将业务定义、审批口径和示例沉淀为可版本化、可审查的 Git 文件，而非埋在提示词里的黑盒。 |
| **核心亮点** | - 受治理的 Text-to-SQL：基于 MDL 语义层规划 + 干跑验证（dry-plan validation）+ 结构化错误提示，从机制上抑制幻觉 SQL。 - 端到端 GenBI 流水线：从自然语言问题 → 受控 SQL → 浏览器端仪表盘（wren-core-wasm），一条命令部署到 Vercel/Cloudflare Pages。 - 知识即代码：业务口径、指令（instructions.md）、成功案例以 Markdown/MDL 文件形式存入 Git，支持 diff 审查与回滚。 - 多源连接与本地化执行：支持 PostgreSQL、ClickHouse、BigQuery 等 22+ 数据源，核心引擎（wren-core）已合并入本仓库，支持 WASM 嵌入式运行。 - 正确性原语：值画像（value profiling）、评估运行器（eval runner）、行数限制与列级安全，为代理生成提供可观测的护栏。 |
| **适用场景** | - 企业内部 BI 自助分析：业务人员用自然语言提问，DBA 或数据工程师在 Git 中维护统一口径，替代“提数-写SQL-做报表”的重复劳动。 - AI Agent 数据接入层：为 Copilot、Chatbot 或自动化工作流提供统一的语义查询接口，避免每个 Agent 各自写死 SQL。 - 多数据源统一治理：在 PostgreSQL、ClickHouse、Snowflake 等混合环境中，通过 MDL 层屏蔽物理表差异，实现跨源一致查询。 - 嵌入式分析产品：利用 wren-core-wasm 在浏览器端直接生成仪表盘，适合 SaaS 产品快速交付内嵌报表功能。 |
| **🛑 DBA 行动指南** | 1. 快速体验（Docker 单机）：      ```bash    git clone https://github.com/Canner/WrenAI.git && cd WrenAI    docker compose up -d   # 启动后访问 localhost:3000    ``` 2. 接入 PostgreSQL 并建模：      - 在 UI 中连接你的 PG 实例（如 `jdbc:postgresql://host:5432/db`）。      - 使用 `wren-cli` 或 UI 导入 schema，重点为关键表补充 MDL 语义（如 `dim_customer.customer_tier` 的枚举值说明）。      - 将生成的 `mdl.json` 提交到 Git 仓库，开启代码审查流程。 3. 验证 SQL 正确性：      - 在 UI 的“Dry Plan”模式中运行典型业务问题（如“上月各区域销售额”），检查生成的 SQL 是否符合行级安全策略。      - 使用内置 eval runner 对 20 条历史问题做回归测试，防止语义层改动导致口径漂移。 4. 生产化部署建议：      - 将 WrenAI 服务与业务库分离部署，仅开放只读账号，并设置 `row_limit` 默认值（如 1000 行）。      - 定期审查 `instructions.md` 中的业务定义，与数仓元数据（如 dbt |



## 📊 附录 · 总榜 Top5（历史 Star 总数）

| 项目 | 总 Star | 板块 | 分类 | 一句话定位 |
| :--- | ---: | :--- | :--- | :--- |
| **[grafana/grafana](https://github.com/grafana/grafana)** | 76.3k | 国外数据库 | 监控 | The open and composable observability and data visualization platform. |
| **[dbeaver/dbeaver](https://github.com/dbeaver/dbeaver)** | 51.4k | 国外数据库 | 平台 | Free universal database tool and SQL client |
| **[drawdb-io/drawdb](https://github.com/drawdb-io/drawdb)** | 39.0k | 国外数据库 | 其他 | Free, simple, and intuitive online database diagram editor and SQL gen |
| **[sqlmapproject/sqlmap](https://github.com/sqlmapproject/sqlmap)** | 38.2k | 国外数据库 | 其他 | Automatic SQL injection and database takeover tool |
| **[chroma-core/chroma](https://github.com/chroma-core/chroma)** | 29.0k | AI工具 | 其他 | Search infrastructure for AI |



## 💬 互动与说明

- 💬 **互动**：本周你最关注哪个项目？欢迎留言分享你的试用体验。
- 📌 **说明**：由 `ai_db_weekly` 基于 GitHub 数据自动采集（截至 2026-08-13）。项目描述来自 GitHub 项目的 description 字段；AI 解读基于项目 README，由 AI 生成，仅供参考。国产数据库板块仅收录在 GitHub 上活跃的开源项目，内核以各厂商官方为准。分类字段采用固定枚举值。


---
