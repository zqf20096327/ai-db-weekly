> **数据库开源周报 · 第 N 期**
> 每周 5 分钟，追踪数据库工具与生态的一手动态。
> _2026-08-09_

> 📌 **数据边界**：本报告聚焦数据库**工具与生态**。数据库内核（PostgreSQL/MySQL/TiDB 等）的版本与发版请以各厂商官方渠道为准。
> 📌 **配套阅读**：本期 [**运维工具合辑周报**](https://mp.weixin.qq.com/)（6 类工具本周动态体检）

---


## ✏️ 本期导语

本周 star 异常上涨（≥100）4 个：WrenAI（+301）、drawdb（+213）、Chat2DB（+202）、LiquiDB（+117）。
新入榜工具 13 个。
本周 33 个工具发版。
无 License 变更。
详见下方各栏。


## 🔍 本周精选解读

### 1. WrenAI 0.29.2

[Canner/WrenAI](https://github.com/Canner/WrenAI) · ⭐ 17.2k（+301） · [发版说明](https://github.com/Canner/WrenAI/releases/tag/0.29.2)

**发生了什么**：WrenAI 于本周发布 0.29.2 版本。本次发版的核心变更为：在 wren-ai-service 中新增了从 Ibis 获取知识的能力，并为 LLMProvider 增加了系统提示词处理逻辑。同时，该版本将 Databricks 正式列入支持的数据库列表。此外，本次发版包含大量依赖升级与安全修复，涉及 wren-ui、wren-ai-service 和 wren-launcher 等多个模块，修复了多项 CVE 漏洞，并升级了 litellm、sqlparse、grpc-go 等关键依赖。最后，UI 侧新增了 Wren AI Cloud 升级入口点。

**为什么值得关注**：WrenAI 是一个开源的生成式商业智能（GenBI）引擎，旨在让 AI 智能体能够基于受治理的文本到 SQL（text-to-SQL）能力，将自然语言问题转化为可信的仪表盘、图表和 SQL 查询。它通过一个开放的 AI 上下文层和语义层（MDL），为智能体提供超越数据库 schema 的业务语义、已批准的定义、示例和记忆，从而解决 AI 生成 SQL 时“自信但错误”的问题。该工具支持超过 22 种数据源，包括 BigQuery、Snowflake、PostgreSQL、ClickHouse 等，并允许智能体生成、部署和治理仪表盘。其核心能力包括受治理的 SQL 生成、基于 MDL 的语义层、知识管理与记忆索引，以及可部署到 Vercel 或 Cloudflare Pages 的浏览器端仪表盘。WrenAI 采用 Apache 2.0 开源协议，核心引擎可自托管，而行级/列级安全、访问控制等高级功能则属于商业版本范畴。

### 2. Chat2DB v5.3.3

[OtterMind/Chat2DB](https://github.com/OtterMind/Chat2DB) · ⭐ 27.8k（+202） · [发版说明](https://github.com/OtterMind/Chat2DB/releases/tag/v5.3.3)

**发生了什么**：Chat2DB Community 5.3.3 于本周发布，主要聚焦桌面端工作区、集成终端和本地文件体验的改进。该版本新增了集成终端、本地文件预览、工作区分屏、可配置的 SQL 与数据库树快捷键、MiniMax AI 模型支持，以及跨数据库方言的无条件标识符引用功能。同时，修复了 95 个问题，涵盖跨数据库的 SQL 与 DDL 安全、DML 与分页校验、存储一致性、结果网格、AI 流所有权、BI 图表、数据库兼容性以及 macOS 打包与启动等方面。此外，还包含 4 项开发与发布工程相关的变更，如严格发布元数据生成、桌面字节码验证和回环受限的开发运行环境。

**为什么值得关注**：Chat2DB 是一个 AI 驱动的跨平台数据库客户端和 SQL 工作台，面向开发者、DBA、分析师和数据团队。它支持 40 多种数据库（包括 MySQL、PostgreSQL、Oracle、SQL Server、ClickHouse、MongoDB、Redis 等），并提供完整的 SQL 编辑、补全、格式化与执行功能。其核心特色是内置 AI 助手，用户可接入自有模型，通过自然语言生成、解释和优化 SQL。此外，它还提供数据库元数据浏览、表与对象管理（DDL/DML）、数据就地编辑、数据导入导出、仪表盘与图表，以及支持 MCP 的开源 CLI。该工具以本地优先、单用户模式运行，并对存储的数据源密码和 AI API 密钥进行 AES-256-GCM 加密。

### 3. grafana v13.0.6

[grafana/grafana](https://github.com/grafana/grafana) · ⭐ 76.2k（+60） · [发版说明](https://github.com/grafana/grafana/releases/tag/v13.0.6)

**发生了什么**：grafana/grafana 本周发布了 v13.0.6 版本。该版本为维护性发版，主要包含 bug 修复和稳定性改进，具体变更内容需参考官方 Release Notes 页面。用户可通过官方下载页面获取该版本，并查阅 What's new highlights 了解新特性概览。

**为什么值得关注**：Grafana 是一个开源的可观测性与数据可视化平台，支持从 Prometheus、Loki、Elasticsearch、InfluxDB、Postgres 等多种数据源查询、可视化、告警并理解指标、日志和链路数据。其核心能力包括：灵活的客户端图表与多种面板插件；通过模板变量创建动态可复用仪表盘；支持即席查询与动态下钻的指标探索；可在保留标签过滤条件的前提下从指标切换至日志分析；可视化定义告警规则并集成 Slack、PagerDuty 等通知渠道；以及在同一图表中混合使用不同数据源。该工具面向需要统一监控与可视化多种数据源的团队，旨在通过共享仪表盘促进数据驱动文化。项目采用 AGPL-3.0-only 许可证，并提供社区论坛、Slack 等渠道供用户参与讨论。




## 📋 工具动态速递

> 本周有发版或显著活跃的数据库工具，每条一句话。无动静的工具不在列。

- 🏷️ `v2.3.0` 🔥108c 📈+18 **[InsForge/InsForge](https://github.com/InsForge/InsForge)** — The all-in-one, open-source backend platform for agentic coding. InsForge gives your coding agent database, auth, storage, compute, hosting, and AI gateway to ship full-stack apps end-to-end.（⭐ 12.7k）
- 🏷️ `v0.27.4` 🔥59c 📈+54 **[warp-tech/warpgate](https://github.com/warp-tech/warpgate)** — Fully transparent SSH, HTTPS, Kubernetes, MySQL and Postgres bastion/PAM that doesn't need additional client-side software（⭐ 7.5k）
- 🏷️ `2026.08.0` 🔥63c 📈+23 **[nocodb/nocodb](https://github.com/nocodb/nocodb)** — 🔥 🔥 🔥 A Free & Self-hostable Airtable Alternative（⭐ 64.4k）
- 🏷️ `26.1.4` 🔥28c 📈+43 **[dbeaver/dbeaver](https://github.com/dbeaver/dbeaver)** — Free universal database tool and SQL client（⭐ 51.3k）
- 🏷️ `v8.0.0-rc.1` 🔥42c 📈+13 **[prisma/prisma](https://github.com/prisma/prisma)** — Next-generation ORM for Node.js & TypeScript / PostgreSQL, MySQL, MariaDB, SQL Server, SQLite, MongoDB and CockroachDB（⭐ 47.5k）
- 🏷️ `4.0.2` 🔥43c 📈+10 **[pawelsalawa/letos](https://github.com/pawelsalawa/letos)** — A free, open source, multi-platform SQLite database manager.（⭐ 6.7k）
- 🏷️ `v7.2.5-premium-beta.2` 🔥39c 📈+6 **[dbgate/dbgate](https://github.com/dbgate/dbgate)** — Database manager for MySQL, PostgreSQL, SQL Server, MongoDB, SQLite and others. Runs under Windows, Linux, Mac or as web application（⭐ 7.2k）
- 🏷️ `v2.58.0` 🔥44c **[smartcontractkit/chainlink](https://github.com/smartcontractkit/chainlink)** — node of the decentralized oracle network, bridging on and off-chain computation（⭐ 8.2k）



## 🆕 新生项目

> 30 天内创建 + star ≥ 3，经相关性过滤。潜力榜已发酵，新星榜为早期观察。

### 🌟 潜力榜（star ≥ 30，已发酵）

| 项目 | 作用 | Star | 创建日 |
|---|---|---:|---|
| [zaber-dev/laravel-quota](https://github.com/zaber-dev/laravel-quota) | Application-level quota management for Laravel with calendar periods, Eloquent integration, middleware, and multiple storage backends. | 106 | 2026-07-11 |
| [albertoarena/laravel-truss](https://github.com/albertoarena/laravel-truss) | A live database structure viewer for Laravel that renders your schema as a scrollable, zoomable ER diagram. Structure only, never data. | 90 | 2026-07-22 |
| [FROWNINGdev/django-orm-lens](https://github.com/FROWNINGdev/django-orm-lens) | Free, MIT alternative to paid Django schema review. Blast radius on every PR, schema drift, N+1 across functions, ER diagrams, MCP server. No DB, no Django boot, no Pro tier. | 59 | 2026-07-12 |
| [indhifarhandika/LunarDump](https://github.com/indhifarhandika/LunarDump) | A lightweight, zero-trust CLI tool built in Python to automate, encrypt, and stream database backups directly to multi-cloud storage. | 38 | 2026-07-29 |
| [MrXujiang/opne-aureka](https://github.com/MrXujiang/opne-aureka) | Upload spreadsheets, ask questions via chat, and auto-generate chart reports. No coding required, gain instant insights and unlock data value effortlessly. ｜上传表格，像聊天一样提问，系统自动分析生成图表报告。无需编程，即时洞察，数据价值触手可及。 | 30 | 2026-07-31 |

### 🆕 新星榜（star 3 ~ 30，早期观察）

> 📌 本档为早期观察信号，仅作记录，不代表成熟可用。

| 项目 | 作用 | Star |
|---|---|---:|
| [kamranata/queue-sql](https://github.com/kamranata/queue-sql) | Queue any Laravel write query (delete/update/insert) across parallel batched jobs. | 28 |
| [h5i-dev/h5i-db](https://github.com/h5i-dev/h5i-db) | An agent-native workspace for quantitative research: an in-terminal notebook, a high-performance time-series database, and a high-throughput backtesting engine. Written in Rust. | 27 |
| [autumoswitzerland/Webduck](https://github.com/autumoswitzerland/Webduck) | A self-hosted DuckDB-as-a-Service server with REST API and Web UI. | 26 |
| [Dicklesworthstone/frankengraphdb](https://github.com/Dicklesworthstone/frankengraphdb) | A blank-slate, memory-safe, ultra-high-performance property-graph database in Rust — unified MVCC/time-travel/branches/replication over a fountain-coded commit stream, WCO+factorized execution, incremental everything, and deterministic auditable results. | 20 |
| [hstptcn5/Catena](https://github.com/hstptcn5/Catena) | Catena exposes any SQLite database as a secure HTTP + WebSocket API in one small Go binary. | 14 |



## 📊 Top 总榜

> 数据库工具按 star 降序。数据库内核（PostgreSQL/MySQL/Redis 等）不在此列，请关注各厂商官方渠道。

| 排名 | 项目 | Star | 作用 |
|:--:|---|---:|---|
| 1 | [grafana/grafana](https://github.com/grafana/grafana) | 76.2k | The open and composable observability and data visualization platform. Visualize metrics, logs, and traces from multiple sources like Prometheus, Loki, Elasticsearch, InfluxDB, Postgres and many more. |
| 2 | [nocodb/nocodb](https://github.com/nocodb/nocodb) | 64.4k | 🔥 🔥 🔥 A Free & Self-hostable Airtable Alternative |
| 3 | [dbeaver/dbeaver](https://github.com/dbeaver/dbeaver) | 51.3k | Free universal database tool and SQL client |
| 4 | [prisma/prisma](https://github.com/prisma/prisma) | 47.5k | Next-generation ORM for Node.js & TypeScript / PostgreSQL, MySQL, MariaDB, SQL Server, SQLite, MongoDB and CockroachDB |
| 5 | [fastapi/full-stack-fastapi-template](https://github.com/fastapi/full-stack-fastapi-template) | 44.7k | Full stack, modern web application template. Using FastAPI, React, SQLModel, PostgreSQL, Docker, GitHub Actions, automatic HTTPS and more. |
| 6 | [drawdb-io/drawdb](https://github.com/drawdb-io/drawdb) | 38.5k | Free, simple, and intuitive online database diagram editor and SQL generator. |
| 7 | [sqlmapproject/sqlmap](https://github.com/sqlmapproject/sqlmap) | 38.1k | Automatic SQL injection and database takeover tool |
| 8 | [typeorm/typeorm](https://github.com/typeorm/typeorm) | 36.6k | TypeScript & JavaScript ORM for Node.js — supports PostgreSQL, MySQL, MariaDB, SQLite, SQL Server, Oracle, and more. |
| 9 | [sequelize/sequelize](https://github.com/sequelize/sequelize) | 30.4k | Feature-rich ORM for modern Node.js and TypeScript, it supports PostgreSQL (with JSON and JSONB support), MySQL, MariaDB, SQLite, MS SQL Server, Snowflake, Oracle DB, DB2 and DB2 for IBM i. |
| 10 | [chroma-core/chroma](https://github.com/chroma-core/chroma) | 29.0k | Search infrastructure for AI |

📎 来源:[GitHub API](https://api.github.com)



## ⚖️ License 雷达

> License 变更可能影响商用，是选型关键信号。

本期无 license 变更事件。



## 📌 关于本报告

**📊 统计口径**
- 数据来自 GitHub 公开 API，截至 2026-08-09
- 仅含数据库**工具**类项目；内核库（PG/MySQL/TiDB 等）版本请关注厂商官方渠道
- "新生项目" = 30 天内创建且 star ≥ 3；"活跃度" = 近 7 日 commit 数

**📎 数据说明**
- Search API 存在索引延迟，新建项目可能滞后数天被索引
- 编辑点评基于项目 release notes 与 README，信息以各项目官方为准

**📂 配套阅读**
- 本期 [**运维工具合辑周报**](https://mp.weixin.qq.com/)：6 类工具本周动态体检、新晋工具、静默观察、类目趋势（发布后替换为链接）


---

**🗂️ 往期回顾 ｜ 👍 点赞 + 在看 ｜ 🔔 关注「数据库开源周报」**
