> **数据库运维工具合辑 · 第 N 期**
> 每周一次，6 类数据库工具的动态体检。
> _2026-08-09_

> 📌 配套阅读：本期 [**主周报**](https://mp.weixin.qq.com/)（含精选解读、新生项目、Top 总榜）
> 📌 **数据边界**：本报告聚焦数据库**工具与生态**。数据库内核（PostgreSQL/MySQL/TiDB 等）的版本与发版请以各厂商官方渠道为准。

---


## ✏️ 本期导语

本周 29 个标杆工具中 **19 个有动态**（发版/活跃/涨星），10 个静默。管理客户端类最活跃（5 个有动态）；连接池 / 代理类整体偏静默（4 个静默）。此外，11 个本周高热度工具此前不在标杆清单，本期起纳入观察。



## 🩺 六类工具体检

> 每类按「有动态 → 静默」排列。🏷️发版 / 🔥活跃(commit) / 📈涨星。

### 连接池 / 代理 — 本周 3 动态 / 4 静默

| 项目 | Star | 本周变化 | 状态 | 作用 |
|---|---:|---|---|---|
| [vitessio/vitess](https://github.com/vitessio/vitess) | 21.2k | 🔥11c 📈+6 | 活跃 | Vitess is a database clustering system for horizontal scaling of MySQL. |
| [pgdogdev/pgdog](https://github.com/pgdogdev/pgdog) | 5.4k | 🔥19c 📈+12 | 活跃 | PostgreSQL connection pooler, load balancer and database sharder. |
| [yandex/odyssey](https://github.com/yandex/odyssey) | 3.6k | 🔥16c | 活跃 | Scalable PostgreSQL connection pooler |
| [flike/kingshard](https://github.com/flike/kingshard) | 6.4k | — 静默 | 静默 | A high-performance MySQL proxy |
| [pgbouncer/pgbouncer](https://github.com/pgbouncer/pgbouncer) | 4.3k | — 静默 | 静默 | lightweight connection pooler for PostgreSQL |
| [postgresml/pgcat](https://github.com/postgresml/pgcat) | 4.0k | — 静默 | 静默 | PostgreSQL pooler with sharding, load balancing and failover support. |
| [XiaoMi/Gaea](https://github.com/XiaoMi/Gaea) | 2.8k | — 静默 | 静默 | Gaea is a mysql proxy, it's developed by xiaomi b2c-dev team. |

### 高可用 / 容灾 — 本周 1 动态 / 3 静默

| 项目 | Star | 本周变化 | 状态 | 作用 |
|---|---:|---|---|---|
| [patroni/patroni](https://github.com/patroni/patroni) | 8.6k | 🔥3c | 活跃 | A template for PostgreSQL High Availability with Etcd, Consul, ZooKeeper, or Kubernetes |
| [zalando/postgres-operator](https://github.com/zalando/postgres-operator) | 5.2k | — 静默 | 静默 | Postgres operator creates and manages PostgreSQL clusters running in Kubernetes |
| [sorintlab/stolon](https://github.com/sorintlab/stolon) | 4.8k | — 静默 | 静默 | PostgreSQL cloud native High Availability and more. |
| [reactive-tech/kubegres](https://github.com/reactive-tech/kubegres) | 1.3k | — 静默 | 静默 | Kubegres is a Kubernetes operator allowing to deploy one or many clusters of PostgreSql instances and manage databases replication, failover and backup. |

### 迁移 / 变更 — 本周 4 动态 / 1 静默

| 项目 | Star | 本周变化 | 状态 | 作用 |
|---|---:|---|---|---|
| [golang-migrate/migrate](https://github.com/golang-migrate/migrate) | 18.8k | 📈+6 | 涨星 | Database migrations. CLI and Golang library. |
| [github/gh-ost](https://github.com/github/gh-ost) | 13.5k | 🔥7c | 活跃 | GitHub's Online Schema-migration Tool for MySQL |
| [flyway/flyway](https://github.com/flyway/flyway) | 10.0k | 🏷️flyway-13.2.0 🔥1c 📈+7 | 发版 | Flyway by Redgate • Database Migrations Made Easy. |
| [sqldef/sqldef](https://github.com/sqldef/sqldef) | 3.1k | 🔥19c | 活跃 | Idempotent schema management for MySQL, PostgreSQL, SQLite, and SQL Server |
| [xataio/pgroll](https://github.com/xataio/pgroll) | 6.5k | — 静默 | 静默 | PostgreSQL zero-downtime migrations made easy |

### 备份 / 恢复 — 本周 3 动态 / 1 静默

| 项目 | Star | 本周变化 | 状态 | 作用 |
|---|---:|---|---|---|
| [databasus/databasus](https://github.com/databasus/databasus) | 7.9k | 📈+23 | 涨星 | PostgreSQL backup tool with Point-In-Time-Recovery and restore verification |
| [David-Crty/databasement](https://github.com/David-Crty/databasement) | 1.9k | 🔥12c 📈+12 | 活跃 | Self-hosted database backup manager with a web UI. Schedule, backup, and restore MySQL, PostgreSQL, MariaDB, Microsoft SQL Server, MongoDB, SQLite & Redis to S3, SFTP, Samba or local storage. SSH Tunnel support. |
| [Aiven-Open/pghoard](https://github.com/Aiven-Open/pghoard) | 1.4k | 🔥2c | 活跃 | PostgreSQL® backup and restore service |
| [EnterpriseDB/barman](https://github.com/EnterpriseDB/barman) | 3.2k | — 静默 | 静默 | Barman - Backup and Recovery Manager for PostgreSQL |

### 监控 / 诊断 — 本周 3 动态 / 0 静默

| 项目 | Star | 本周变化 | 状态 | 作用 |
|---|---:|---|---|---|
| [grafana/grafana](https://github.com/grafana/grafana) | 76.2k | 🏷️v13.0.6 🔥193c 📈+60 | 发版 | The open and composable observability and data visualization platform. Visualize metrics, logs, and traces from multiple sources like Prometheus, Loki, Elasticsearch, InfluxDB, Postgres and many more. |
| [VictoriaMetrics/VictoriaMetrics](https://github.com/VictoriaMetrics/VictoriaMetrics) | 17.5k | 🏷️v1.149.0 🔥9c 📈+23 | 发版 | VictoriaMetrics: fast, cost-effective monitoring solution and time series database |
| [erikdarlingdata/PerformanceMonitor](https://github.com/erikdarlingdata/PerformanceMonitor) | 468 | 🔥212c 📈+6 | 活跃 | Free, open-source SQL Server performance monitoring — 32 collectors, real-time alerts, graphical plan viewer, MCP server for AI analysis. Supports SQL 2016-2025, Azure SQL, AWS RDS. |

### 管理客户端 — 本周 5 动态 / 1 静默

| 项目 | Star | 本周变化 | 状态 | 作用 |
|---|---:|---|---|---|
| [dbeaver/dbeaver](https://github.com/dbeaver/dbeaver) | 51.3k | 🏷️26.1.4 🔥28c 📈+43 | 发版 | Free universal database tool and SQL client |
| [sqlitebrowser/sqlitebrowser](https://github.com/sqlitebrowser/sqlitebrowser) | 24.4k | 🏷️nightly 🔥3c 📈+13 | 发版 | Official home of the DB Browser for SQLite (DB4S) project. Previously known as "SQLite Database Browser" and "Database Browser for SQLite". Website at: |
| [beekeeper-studio/beekeeper-studio](https://github.com/beekeeper-studio/beekeeper-studio) | 23.3k | 🔥109c 📈+18 | 活跃 | Modern and easy to use SQL client for MySQL, Postgres, SQLite, SQL Server, and more. Linux, MacOS, and Windows. |
| [chartdb/chartdb](https://github.com/chartdb/chartdb) | 22.7k | 📈+9 | 涨星 | Database diagrams editor that allows you to visualize and design your DB with a single query. |
| [dbgate/dbgate](https://github.com/dbgate/dbgate) | 7.2k | 🏷️v7.2.5-premium-beta.2 🔥39c 📈+6 | 发版 | Database manager for MySQL, PostgreSQL, SQL Server, MongoDB, SQLite and others. Runs under Windows, Linux, Mac or as web application |
| [sosedoff/pgweb](https://github.com/sosedoff/pgweb) | 9.5k | — 静默 | 静默 | Cross-platform client for PostgreSQL databases |



## 🆕 本周新晋工具

> 不在标杆清单、但本周发版或高涨幅的工具，纳入观察。

| 项目 | Star | 本周变化 | 归类 | 作用 |
|---|---:|---|---|---|
| [drawdb-io/drawdb](https://github.com/drawdb-io/drawdb) | 38.5k | 🔥2c 📈+213 | 其他 | Free, simple, and intuitive online database diagram editor and SQL generator.（深度解读见主周报） |
| [OtterMind/Chat2DB](https://github.com/OtterMind/Chat2DB) | 27.8k | 🏷️v5.3.3 🔥123c 📈+202 | 管理客户端 | 🔥🔥🔥 AI-driven database tool and SQL client, The hottest GUI client, supporting MySQL, Oracle, PostgreSQL, DB2, SQL Server, DB2, SQLite, H2, ClickHouse, and more.（深度解读见主周报） |
| [Canner/WrenAI](https://github.com/Canner/WrenAI) | 17.2k | 🏷️0.29.2 🔥10c 📈+301 | AI 工具 | GenBI (Generative BI) for AI agents, an open-source, governed text-to-SQL through an open context layer that turns natural-language questions into trusted dashboards, charts, and SQL across 20+ data sources, such as BigQuery, Snowflake, PostgreSQL, ClickHouse, Amazon Redshift, Databricks and more.（深度解读见主周报） |
| [smartcontractkit/chainlink](https://github.com/smartcontractkit/chainlink) | 8.2k | 🏷️v2.58.0 🔥44c | 其他 | node of the decentralized oracle network, bridging on and off-chain computation |
| [supabase/realtime](https://github.com/supabase/realtime) | 7.6k | 🏷️v2.124.2 🔥22c | 其他 | Broadcast, Presence, and Postgres Changes via WebSockets |
| [msiemens/tinydb](https://github.com/msiemens/tinydb) | 7.5k | 🏷️v4.9.0 🔥5c | 其他 | TinyDB is a lightweight document oriented database optimized for your happiness :) |
| [warp-tech/warpgate](https://github.com/warp-tech/warpgate) | 7.5k | 🏷️v0.27.4 🔥59c 📈+54 | 连接池/代理 | Fully transparent SSH, HTTPS, Kubernetes, MySQL and Postgres bastion/PAM that doesn't need additional client-side software |
| [jOOQ/jOOQ](https://github.com/jOOQ/jOOQ) | 6.8k | 🏷️version-3.19.37 🔥3c | 其他 | jOOQ is the best way to write SQL in Java |



## 😴 静默观察

> 本周无发版、无 commit、无涨星的标杆工具。持续静默可能意味着维护放缓，选型时留意。

**连接池 / 代理**：flike/kingshard · pgbouncer/pgbouncer · postgresml/pgcat · XiaoMi/Gaea
**高可用 / 容灾**：zalando/postgres-operator · sorintlab/stolon · reactive-tech/kubegres
**迁移 / 变更**：xataio/pgroll
**备份 / 恢复**：EnterpriseDB/barman
**管理客户端**：sosedoff/pgweb

> 📊 本周静默率 10/29（34%）。
连接池 / 代理类静默率最高（4/7）。



## 📊 类目趋势速览

| 类目 | 工具数 | 本周动态 | 静默 | 类目 star 净增 |
|---|:--:|:--:|:--:|---:|
| 连接池 / 代理 | 7 | 3 | 4 | +21 |
| 高可用 / 容灾 | 4 | 1 | 3 | +6 |
| 迁移 / 变更 | 5 | 4 | 1 | +19 |
| 备份 / 恢复 | 4 | 3 | 1 | +38 |
| 监控 / 诊断 | 3 | 3 | 0 | +89 |
| 管理客户端 | 6 | 5 | 1 | +94 |
| **合计** | **29** | **19** | **10** | **+267** |



## 📌 关于本期

**📊 统计口径**
- 数据来自 GitHub 公开 API，截至 2026-08-09
- "动态" = 本周有发版（🏷️）/ 近 7 日有 commit（🔥）/ star 净增 > 5（📈），任一满足即算
- "静默" = 以上三项均无
- 标杆清单每季度评审一次，增减工具；新晋工具每周动态纳入

**📎 相关阅读**
- 本期 [**主周报**](https://mp.weixin.qq.com/)：精选解读、新生项目、Top 总榜、License 雷达


---

**🗂️ 往期合辑 ｜ 👍 点赞 + 在看 ｜ 🔔 关注「数据库开源周报」**
