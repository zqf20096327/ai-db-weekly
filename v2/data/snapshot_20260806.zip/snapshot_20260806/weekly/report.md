> **每周 5 分钟，看懂 GitHub 上数据库开源生态的一手动态。**
> **本期重点：本周重点关注：drawdb、WrenAI。**
> _采集日 2026-08-07_


## ① ⭐ 快速上涨榜

> 口径：7 日 star 净增排序，排除总榜前 5（只看腰部黑马）。负值不上榜。

| 项目 | 本周净增 | 当前 Star | 备注 |
|---|---:|---:|---|
| [Canner/WrenAI](https://github.com/Canner/WrenAI) | +210 | 17.1k |  |
| [FalkorDB/FalkorDB](https://github.com/FalkorDB/FalkorDB) | +53 | 5.4k |  |
| [drawdb-io/drawdb](https://github.com/drawdb-io/drawdb) | +43 | 38.3k |  |
| [duckdb/duckdb](https://github.com/duckdb/duckdb) | +33 | 40.0k |  |
| [authzed/spicedb](https://github.com/authzed/spicedb) | +26 | 6.9k |  |
| [ClickHouse/ClickHouse](https://github.com/ClickHouse/ClickHouse) | +23 | 49.1k |  |
| [OtterMind/Chat2DB](https://github.com/OtterMind/Chat2DB) | +23 | 27.7k |  |
| [tursodatabase/turso](https://github.com/tursodatabase/turso) | +21 | 23.7k |  |
| [sinaptik-ai/pandas-ai](https://github.com/sinaptik-ai/pandas-ai) | +17 | 23.7k |  |
| [apache/doris](https://github.com/apache/doris) | +16 | 15.7k |  |

📎 来源:[GitHub API](https://api.github.com)


## ② 🆕 新生项目

> 口径：30 天内创建 + star ≥ 3，经内容相关性过滤后分双档展示。

### 🌟 潜力榜（star ≥ 30，已发酵）

| 项目 | 作用 | Star | 创建日 |
|---|---|---:|---|
| [zaber-dev/laravel-quota](https://github.com/zaber-dev/laravel-quota) | Application-level quota management for Laravel with calendar periods, Eloquent integration, middleware, and multiple storage backends. | 106 | 2026-07-11 |
| [albertoarena/laravel-truss](https://github.com/albertoarena/laravel-truss) | A live database structure viewer for Laravel that renders your schema as a scrollable, zoomable ER diagram. Structure only, never data. | 88 | 2026-07-22 |
| [FROWNINGdev/django-orm-lens](https://github.com/FROWNINGdev/django-orm-lens) | Free, MIT alternative to paid Django schema review. Blast radius on every PR, schema drift, N+1 across functions, ER diagrams, MCP server. No DB, no Django boot, no Pro tier. | 58 | 2026-07-12 |
| [indhifarhandika/LunarDump](https://github.com/indhifarhandika/LunarDump) | A lightweight, zero-trust CLI tool built in Python to automate, encrypt, and stream database backups directly to multi-cloud storage. | 38 | 2026-07-29 |
| [feigeCode/navop](https://github.com/feigeCode/navop) | A native, all-in-one workspace for databases, SSH, SFTP, terminals, remote desktop, monitoring, and AI. | 311 | 2026-07-10 |
| [youxiandechilun/Guido](https://github.com/youxiandechilun/Guido) | 景区导览服务 AI 数字人：基于 Spring Boot、Vue 3、UniApp 与本地 RAG 的智能导览系统。 | 61 | 2026-07-11 |
| [apitap/apitap-lib](https://github.com/apitap/apitap-lib) | Move whole tables between databases fast — Postgres, MySQL, ClickHouse, BigQuery. Rust engine, one-line Python API, bounded memory. | 47 | 2026-07-11 |
| [Audreator/Simlect-AI-Mall](https://github.com/Audreator/Simlect-AI-Mall) | 把对话导购和智能客服融入到传统电商中：Spring Cloud 微服务 + Python Agent，支持搜商品、查订单、售后提案确认。在线体验 www.simlect.com | 31 | 2026-07-18 |
| [super-productivity/plainspace](https://github.com/super-productivity/plainspace) | A small shared workspace for tasks, notes, polls, and planning — self-hostable and touch-first | 90 | 2026-07-11 |
| [manor-os/manor-ai](https://github.com/manor-os/manor-ai) | Source-available, self-hosted AI agent workspace for small businesses and lean teams — with BYOK, workflows, tools, and human approvals. | 49 | 2026-07-12 |

### 🆕 新星榜（star 3 ~ 30，早期观察）

> 📌 本档为早期观察信号，仅作记录，不代表成熟可用。

| 项目 | 作用 | Star |
|---|---|---:|
| [totalumlabs/ai-app-builder-open](https://github.com/totalumlabs/ai-app-builder-open) | Open-source AI app builder — turn a prompt into a full-stack Next.js web app with built-in hosting, sandbox, database, auth, AI integration, github bidirectional, multitenant, custom domain & more. Self-hosted, no-code. A free v0 / Lovable / Bolt / Replit alternative. ⭐ | 29 |
| [kamranata/queue-sql](https://github.com/kamranata/queue-sql) | Queue any Laravel write query (delete/update/insert) across parallel batched jobs. | 28 |
| [MrXujiang/opne-aureka](https://github.com/MrXujiang/opne-aureka) | Upload spreadsheets, ask questions via chat, and auto-generate chart reports. No coding required, gain instant insights and unlock data value effortlessly. ｜上传表格，像聊天一样提问，系统自动分析生成图表报告。无需编程，即时洞察，数据价值触手可及。 | 27 |
| [SecureWithUmer/CVE-2026-PoCs](https://github.com/SecureWithUmer/CVE-2026-PoCs) | A community-curated, verified collection of Proof-of-Concept exploits for CVEs disclosed in 2026. | 27 |
| [h5i-dev/h5i-db](https://github.com/h5i-dev/h5i-db) | An agent-native workspace for quantitative research: an in-terminal notebook, a high-performance time-series database, and a high-throughput backtesting engine. Written in Rust. | 26 |
| [autumoswitzerland/Webduck](https://github.com/autumoswitzerland/Webduck) | A self-hosted DuckDB-as-a-Service server with REST API and Web UI. | 22 |
| [Dicklesworthstone/frankengraphdb](https://github.com/Dicklesworthstone/frankengraphdb) | A blank-slate, memory-safe, ultra-high-performance property-graph database in Rust — unified MVCC/time-travel/branches/replication over a fountain-coded commit stream, WCO+factorized execution, incremental everything, and deterministic auditable results. | 20 |
| [hstptcn5/Catena](https://github.com/hstptcn5/Catena) | Catena exposes any SQLite database as a secure HTTP + WebSocket API in one small Go binary. | 14 |
| [phuc-nt/my-db-mate](https://github.com/phuc-nt/my-db-mate) | Self-hosted chat-with-your-database: natural-language questions answered by real read-only SQL, with a curated context layer and a physical safety layer. Next.js + TypeScript. | 14 |
| [waynesutton/Codex-Sites-Convex-Backend-Skill](https://github.com/waynesutton/Codex-Sites-Convex-Backend-Skill) | Build and ship a Codex Site with Convex as its realtime database and backend—using one reusable Codex skill. | 12 |

> 📌 topic 标签由作者自填不可靠，已过滤打数据库标签但与数据库无关的项目。仅保留『本身是数据库相关』的项目。


## ④ ⭐ 本周重点分析

> 📌 本栏目为 AI 辅助解读，以官方文档为准。

### ⭐ drawdb-io/drawdb

（信号分 45：star 净增进入快速上涨榜前3）

**1️⃣ 这个项目做什么**

**drawdb-io/drawdb**：Free, simple, and intuitive online database diagram editor and SQL generator.


**2️⃣ 解决什么问题**

_（本期为骨架版，待读取官方文档后由 AI 补充面向场景）_


**3️⃣ 有哪些突出点（基于官方 release notes 转述）**

_（本期为骨架版，待 AI 基于 release notes 转述特性，不评判）_


**4️⃣ 为什么解读它**

本周信号分最高：star 净增进入快速上涨榜前3，故入选。当前 star 38311。


📎 来源:[drawdb-io/drawdb](https://github.com/drawdb-io/drawdb)

### ⭐ Canner/WrenAI

（信号分 45：star 净增进入快速上涨榜前3）

**1️⃣ 这个项目做什么**

**Canner/WrenAI**：GenBI (Generative BI) for AI agents, an open-source, governed text-to-SQL through an open context layer that turns natural-language questions into trusted dashboards, charts, and SQL across 20+ data sources, such as BigQuery, Snowflake, PostgreSQL, ClickHouse, Amazon Redshift, Databricks and more.


**2️⃣ 解决什么问题**

_（本期为骨架版，待读取官方文档后由 AI 补充面向场景）_


**3️⃣ 有哪些突出点（基于官方 release notes 转述）**

_（本期为骨架版，待 AI 基于 release notes 转述特性，不评判）_


**4️⃣ 为什么解读它**

本周信号分最高：star 净增进入快速上涨榜前3，故入选。当前 star 17091。


📎 来源:[Canner/WrenAI](https://github.com/Canner/WrenAI)


## ⑤ 📊 Top 总榜（含 🔥 活跃标签）

> 口径：所有项目统一按 star 降序。🔥 = 近 7 天 commit 活跃（达阈值）。

| 排名 | 项目 | 品类 | Star | 活跃 | 本周变化 |
|:--:|---|---|---:|:--:|---|
| 1 | [grafana/grafana](https://github.com/grafana/grafana) | 生态工具 | 76.1k | 🔥 | ↑ +27 |
| 2 | [redis/redis](https://github.com/redis/redis) | 生态工具 | 75.9k | 🔥 | ↑ +23 |
| 3 | [nocodb/nocodb](https://github.com/nocodb/nocodb) | 生态工具 | 64.4k | 🔥 | ↑ +10 |
| 4 | [meilisearch/meilisearch](https://github.com/meilisearch/meilisearch) | 生态工具 | 58.9k | 🔥 | ↑ +21 |
| 5 | [etcd-io/etcd](https://github.com/etcd-io/etcd) | 生态工具 | 52.1k | 🔥 | ↑ +7 |
| 6 | [dbeaver/dbeaver](https://github.com/dbeaver/dbeaver) | 生态工具 | 51.3k | 🔥 | ↑ +15 |
| 7 | [ClickHouse/ClickHouse](https://github.com/ClickHouse/ClickHouse) | 生态工具 | 49.1k | 🔥 | 见①快速上涨 |
| 8 | [prisma/prisma](https://github.com/prisma/prisma) | 生态工具 | 47.5k | 🔥 | ↑ +7 |
| 9 | [fastapi/full-stack-fastapi-template](https://github.com/fastapi/full-stack-fastapi-template) | 生态工具 | 44.6k | 🔥 | ↑ +15 |
| 10 | [pingcap/tidb](https://github.com/pingcap/tidb) | 数据库内核 | 40.4k | 🔥 | 见⑧AI 能力专题 |
| 11 | [duckdb/duckdb](https://github.com/duckdb/duckdb) | 数据库内核 | 40.0k | 🔥 | 见①快速上涨 |
| 12 | [drawdb-io/drawdb](https://github.com/drawdb-io/drawdb) | 生态工具 | 38.3k |  | 见④本周重点 |
| 13 | [sqlmapproject/sqlmap](https://github.com/sqlmapproject/sqlmap) | 生态工具 | 38.1k | 🔥 | ↑ +9 |
| 14 | [typeorm/typeorm](https://github.com/typeorm/typeorm) | 生态工具 | 36.6k |  | — |
| 15 | [surrealdb/surrealdb](https://github.com/surrealdb/surrealdb) | 生态工具 | 32.8k |  | ↑ +3 |
| 16 | [cockroachdb/cockroach](https://github.com/cockroachdb/cockroach) | 数据库内核 | 32.4k | 🔥 | ↑ +4 |
| 17 | [facebook/rocksdb](https://github.com/facebook/rocksdb) | 生态工具 | 31.9k | 🔥 | ↑ +3 |
| 18 | [dragonflydb/dragonfly](https://github.com/dragonflydb/dragonfly) | 生态工具 | 31.0k | 🔥 | ↑ +9 |
| 19 | [sequelize/sequelize](https://github.com/sequelize/sequelize) | 生态工具 | 30.4k |  | ↓ -1 |
| 20 | [chroma-core/chroma](https://github.com/chroma-core/chroma) | AI | 29.0k |  | 见⑧AI 能力专题 |

📎 来源:[GitHub API](https://api.github.com)


## ⑥ 📦 版本速递

> 口径：本周发版的、进候选池的项目。同项目多次发版只列最新版并标注。notes AI 忠实摘要。

### 6a 🛠️ 生态工具版本

| 项目 | 版本 | 日期 | 要点 |
|---|---|---|---|
| [prisma/prisma](https://github.com/prisma/prisma/releases/tag/v8.0.0-rc.1) | v8.0.0-rc.1 | 2026-08-07 | > # v8.0.0-rc.1  This is the first release on the v8 re（本周共 2 版） |
| [get-convex/convex-backend](https://github.com/get-convex/convex-backend/releases/tag/precompiled-2026-08-07-c45075f) | precompiled-2026-08-07-c45075f | 2026-08-07 | `precompiled-2026-08-07-c45075f` 官方 Release Notes 暂无正文（（本周共 13 版） |
| [grafana/grafana](https://github.com/grafana/grafana/releases/tag/v13.0.6) | v13.0.6 | 2026-08-07 | > [Download page](https://grafana.com/grafana/download/（本周共 7 版） |
| [tursodatabase/turso](https://github.com/tursodatabase/turso/releases/tag/v0.8.0-pre.3) | v0.8.0-pre.3 | 2026-08-06 | > ## Install turso_cli 0.8.0-pre.3  ### Install prebuil |
| [flyway/flyway](https://github.com/flyway/flyway/releases/tag/flyway-13.2.0) | flyway-13.2.0 | 2026-08-06 | > See release notes [here](https://documentation.red-ga |
| [ClickHouse/ClickHouse](https://github.com/ClickHouse/ClickHouse/releases/tag/v26.7.3.19-stable) | v26.7.3.19-stable | 2026-08-06 | `v26.7.3.19-stable` 官方 Release Notes 暂无正文（详见出处链接）。（本周共 7 版） |
| [dragonflydb/dragonfly](https://github.com/dragonflydb/dragonfly/releases/tag/v1.40.1) | v1.40.1 | 2026-08-06 | > ## This is a patch release.  ### What's Changed  - Fi（本周共 2 版） |
| [VictoriaMetrics/VictoriaMetrics](https://github.com/VictoriaMetrics/VictoriaMetrics/releases/tag/v1.149.0) | v1.149.0 | 2026-08-05 | > ## [v1.149.0](https://github.com/VictoriaMetrics/Vict（本周共 3 版） |

### 6b 🤖 AI 板块版本

| 项目 | 版本 | 日期 | 要点 |
|---|---|---|---|
| [databendlabs/databend](https://github.com/databendlabs/databend/releases/tag/v1.2.879-patch.2) | v1.2.879-patch.2 | 2026-08-07 | > <!-- Release notes generated using configuration in .（本周共 3 版） |
| [OtterMind/Chat2DB](https://github.com/OtterMind/Chat2DB/releases/tag/v5.3.3) | v5.3.3 | 2026-08-06 | > Chat2DB Community 5.3.3 focuses on the desktop worksp |
| [Canner/WrenAI](https://github.com/Canner/WrenAI/releases/tag/0.29.2) | 0.29.2 | 2026-08-05 | > ## What's Changed * Add Databricks to the list of sup |



## ⑦ 🛠️ 生态工具

> 发现方式：topic + 工具关键词。归类依据项目 README 自述。AI 翻译作用，不点评。

### 中间件 / 代理

- **[patroni/patroni](https://github.com/patroni/patroni)** ⭐ 8.6k —— A template for PostgreSQL High Availability with Etcd, Consul, ZooKeeper, or Kubernetes
- **[warp-tech/warpgate](https://github.com/warp-tech/warpgate)** ⭐ 7.5k —— Fully transparent SSH, HTTPS, Kubernetes, MySQL and Postgres bastion/PAM that doesn't need additional client-side software
- **[flike/kingshard](https://github.com/flike/kingshard)** ⭐ 6.4k —— A high-performance MySQL proxy
- **[pgdogdev/pgdog](https://github.com/pgdogdev/pgdog)** ⭐ 5.4k —— PostgreSQL connection pooler, load balancer and database sharder.
- **[pgbouncer/pgbouncer](https://github.com/pgbouncer/pgbouncer)** ⭐ 4.3k —— lightweight connection pooler for PostgreSQL
- **[postgresml/pgcat](https://github.com/postgresml/pgcat)** ⭐ 4.0k —— PostgreSQL pooler with sharding, load balancing and failover support.
- **[yandex/odyssey](https://github.com/yandex/odyssey)** ⭐ 3.6k —— Scalable PostgreSQL connection pooler
- **[XiaoMi/Gaea](https://github.com/XiaoMi/Gaea)** ⭐ 2.8k —— Gaea is a mysql proxy, it's developed by xiaomi b2c-dev team.

### 高可用 / 编排

- **[grafana/grafana](https://github.com/grafana/grafana)** ⭐ 76.1k —— The open and composable observability and data visualization platform. Visualize metrics, logs, and traces from multiple sources like Prometheus, Loki, Elasticsearch, InfluxDB, Postgres and many more.
- **[nocodb/nocodb](https://github.com/nocodb/nocodb)** ⭐ 64.4k —— 🔥 🔥 🔥 A Free & Self-hostable Airtable Alternative
- **[ClickHouse/ClickHouse](https://github.com/ClickHouse/ClickHouse)** ⭐ 49.1k —— ClickHouse® is a real-time analytics database management system
- **[fastapi/full-stack-fastapi-template](https://github.com/fastapi/full-stack-fastapi-template)** ⭐ 44.6k —— Full stack, modern web application template. Using FastAPI, React, SQLModel, PostgreSQL, Docker, GitHub Actions, automatic HTTPS and more.
- **[pingcap/tidb](https://github.com/pingcap/tidb)** ⭐ 40.4k —— TiDB is built for agentic workloads that grow unpredictably, with ACID guarantees and native support for transactions, analytics, and vector search. No data silos. No noisy neighbors. No infrastructure ceiling.
- **[typeorm/typeorm](https://github.com/typeorm/typeorm)** ⭐ 36.6k —— TypeScript & JavaScript ORM for Node.js — supports PostgreSQL, MySQL, MariaDB, SQLite, SQL Server, Oracle, and more.
- **[cockroachdb/cockroach](https://github.com/cockroachdb/cockroach)** ⭐ 32.4k —— CockroachDB — the cloud native, distributed SQL database designed for high availability, effortless scale, and control over data placement.
- **[facebook/rocksdb](https://github.com/facebook/rocksdb)** ⭐ 31.9k —— A library that provides an embeddable, persistent key-value store for fast storage.

### 管控 / 治理

- **[dbeaver/dbeaver](https://github.com/dbeaver/dbeaver)** ⭐ 51.3k —— Free universal database tool and SQL client
- **[prisma/prisma](https://github.com/prisma/prisma)** ⭐ 47.5k —— Next-generation ORM for Node.js & TypeScript / PostgreSQL, MySQL, MariaDB, SQL Server, SQLite, MongoDB and CockroachDB
- **[sequelize/sequelize](https://github.com/sequelize/sequelize)** ⭐ 30.4k —— Feature-rich ORM for modern Node.js and TypeScript, it supports PostgreSQL (with JSON and JSONB support), MySQL, MariaDB, SQLite, MS SQL Server, Snowflake, Oracle DB, DB2 and DB2 for IBM i.
- **[taosdata/TDengine](https://github.com/taosdata/TDengine)** ⭐ 25.0k —— High-performance, scalable time-series database designed for Industrial IoT (IIoT) scenarios
- **[sqlitebrowser/sqlitebrowser](https://github.com/sqlitebrowser/sqlitebrowser)** ⭐ 24.4k —— Official home of the DB Browser for SQLite (DB4S) project. Previously known as "SQLite Database Browser" and "Database Browser for SQLite". Website at:
- **[beekeeper-studio/beekeeper-studio](https://github.com/beekeeper-studio/beekeeper-studio)** ⭐ 23.3k —— Modern and easy to use SQL client for MySQL, Postgres, SQLite, SQL Server, and more. Linux, MacOS, and Windows.
- **[dgraph-io/dgraph](https://github.com/dgraph-io/dgraph)** ⭐ 21.8k —— high-performance graph database for real-time use cases
- **[mysqljs/mysql](https://github.com/mysqljs/mysql)** ⭐ 18.6k —— A pure node.js JavaScript Client implementing the MySQL protocol.

### 迁移 / 备份

- **[transact-rs/sqlx](https://github.com/transact-rs/sqlx)** ⭐ 17.4k —— 🧰 The Rust SQL Toolkit. An async, pure Rust SQL crate featuring compile-time checked queries without a DSL. Supports PostgreSQL, MySQL, and SQLite.
- **[realm/realm-swift](https://github.com/realm/realm-swift)** ⭐ 16.6k —— Realm is a mobile database: a replacement for Core Data & SQLite
- **[github/gh-ost](https://github.com/github/gh-ost)** ⭐ 13.5k —— GitHub's Online Schema-migration Tool for MySQL
- **[flyway/flyway](https://github.com/flyway/flyway)** ⭐ 10.0k —— Flyway by Redgate • Database Migrations Made Easy.
- **[databasus/databasus](https://github.com/databasus/databasus)** ⭐ 7.9k —— PostgreSQL backup tool with Point-In-Time-Recovery and restore verification
- **[sorintlab/stolon](https://github.com/sorintlab/stolon)** ⭐ 4.8k —— PostgreSQL cloud native High Availability and more.
- **[objectbox/objectbox-java](https://github.com/objectbox/objectbox-java)** ⭐ 4.6k —— Database for Android and JVM - first and fast, lightweight on-device vector database
- **[aws/aws-sdk-pandas](https://github.com/aws/aws-sdk-pandas)** ⭐ 4.1k —— pandas on AWS - Easy integration with Athena, Glue, Redshift, Timestream, Neptune, OpenSearch, QuickSight, Chime, CloudWatchLogs, DynamoDB, EMR, SecretManager, PostgreSQL, MySQL, SQLServer and S3 (Parquet, CSV, JSON and EXCEL).

📎 来源:[各项目 GitHub 仓库 README](https://github.com)


## ⑧ 🤖 AI 能力专题

> 发现方式：topic + AI 关键词。不分类，直接按 star 展示 top。

| 排名 | 项目 | 作用（AI 翻译） | Star |
|:--:|---|---|---:|
| 1 | [pingcap/tidb](https://github.com/pingcap/tidb) | TiDB is built for agentic workloads that grow unpredictably, with ACID guarantees and native support for transactions, analytics, and vector search. No data silos. No noisy neighbors. No infrastructure ceiling. | 40.4k |
| 2 | [chroma-core/chroma](https://github.com/chroma-core/chroma) | Search infrastructure for AI | 29.0k |
| 3 | [OtterMind/Chat2DB](https://github.com/OtterMind/Chat2DB) | 🔥🔥🔥 AI-driven database tool and SQL client, The hottest GUI client, supporting MySQL, Oracle, PostgreSQL, DB2, SQL Server, DB2, SQLite, H2, ClickHouse, and more. | 27.7k |
| 4 | [sinaptik-ai/pandas-ai](https://github.com/sinaptik-ai/pandas-ai) | Chat with your database or your datalake (SQL, CSV, parquet). PandasAI makes data analysis conversational using LLMs and RAG. | 23.7k |
| 5 | [Canner/WrenAI](https://github.com/Canner/WrenAI) | GenBI (Generative BI) for AI agents, an open-source, governed text-to-SQL through an open context layer that turns natural-language questions into trusted dashboards, charts, and SQL across 20+ data sources, such as BigQuery, Snowflake, PostgreSQL, ClickHouse, Amazon Redshift, Databricks and more. | 17.1k |
| 6 | [apache/doris](https://github.com/apache/doris) | Apache Doris is a real-time analytics and hybrid search database for AI agents. | 15.7k |
| 7 | [bytebase/bytebase](https://github.com/bytebase/bytebase) | Database governance built for humans and agents — controlling changes and access across every major database. | 14.4k |
| 8 | [InsForge/InsForge](https://github.com/InsForge/InsForge) | The all-in-one, open-source backend platform for agentic coding. InsForge gives your coding agent database, auth, storage, compute, hosting, and AI gateway to ship full-stack apps end-to-end. | 12.7k |
| 9 | [databendlabs/databend](https://github.com/databendlabs/databend) | Data Agent Ready Warehouse : One for  Analytics, Search, AI, Python Sandbox.  — rebuilt from scratch. Unified architecture on your S3. | 9.4k |
| 10 | [sqlchat/sqlchat](https://github.com/sqlchat/sqlchat) | Chat-based SQL Client and Editor for the next decade | 5.8k |
| 11 | [FalkorDB/FalkorDB](https://github.com/FalkorDB/FalkorDB) | A super fast Graph Database uses GraphBLAS under the hood for its sparse adjacency matrix graph representation. Our goal is to provide the best Knowledge Graph for LLM (GraphRAG). | 5.4k |
| 12 | [mathesar-foundation/mathesar](https://github.com/mathesar-foundation/mathesar) | An intuitive spreadsheet-like interface that lets users of all technical skill levels view, edit, query, and collaborate on Postgres data directly. 100% open source and self hosted, with native Postgres access control. | 5.1k |
| 13 | [TabularisDB/tabularis](https://github.com/TabularisDB/tabularis) | Open-source desktop SQL workspace for PostgreSQL, MySQL/MariaDB, SQLite and 15+ more databases like DuckDB, ClickHouse, Redis and Firestore. Built-in MCP server for Claude, Cursor and Devin, SQL notebooks and visual EXPLAIN. | 4.0k |
| 14 | [Dataherald/dataherald](https://github.com/Dataherald/dataherald) | Interact with your SQL database, Natural Language to SQL using LLMs | 3.6k |
| 15 | [bytebase/dbhub](https://github.com/bytebase/dbhub) | Minimal database MCP server for Postgres, MySQL, SQL Server, MariaDB, SQLite. | 3.3k |

📎 来源:[GitHub Search API + 各项目 README](https://api.github.com)


## ⑨ ⚖️ License 雷达

> 本期无 license 变更事件。

### 📎 License 全景表（头部项目）

| 项目 | License |
|---|---|
| macrozheng/mall | Apache-2.0 |
| grafana/grafana | AGPL-3.0 |
| redis/redis | NOASSERTION |
| strapi/strapi | NOASSERTION |
| nocodb/nocodb | NOASSERTION |
| coollabsio/coolify | Apache-2.0 |
| meilisearch/meilisearch | NOASSERTION |
| makeplane/plane | AGPL-3.0 |
| twentyhq/twenty | NOASSERTION |
| etcd-io/etcd | Apache-2.0 |
| dbeaver/dbeaver | Apache-2.0 |
| ClickHouse/ClickHouse | Apache-2.0 |
| discourse/discourse | GPL-2.0 |
| prisma/prisma | Apache-2.0 |
| calcom/cal.diy | MIT |

> NOASSERTION = 非 OSI 认证的自定义协议，生产商用前建议阅读 LICENSE 原文。以上为 GitHub 仓库字段读取，详情以各项目 LICENSE 文件为准。


## 📌 统计口径与说明

**📊 统计口径**
  • star 数据取自 GitHub API，截至 2026-08-07
  • "快速上涨" = 7 日 star 净增排序，排除总榜前 5
  • "新生项目" = 30 天内创建且 star ≥ 3，经内容相关性过滤后分双档展示
  • "活跃度"（⑤总榜🔥标签）= 近 7 天 commit 达阈值
  • 覆盖范围：关系型数据库 + 生态工具 + AI 能力


**📎 数据说明**
  • 数据来自 GitHub 公开 API
  • Search API 存在索引延迟，新建项目可能滞后数天被索引
  • 所有版本特性、license 信息以各项目官方文档及 LICENSE 文件为准


**🗂️ 往期回顾 ｜ 👍 点赞 + 在看 ｜ 🔔 关注「数据库开源周报」，下周见**
