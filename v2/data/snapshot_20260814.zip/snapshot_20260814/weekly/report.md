# 📋 数据库开源生态周报 · 第 N 期

> 📌 **数据源**：GitHub。聚焦开源工具与实验项目，不涉及厂商内核信息。生产可用性请自行评估。

> _2026-08-14_

---

## 📌 本周 DBA 速览

- 🗄️ **国外数据库**：[drawdb](https://github.com/drawdb-io/drawdb)（+552）—— Free, simple, and intuitive online database diagram editor a
- 🇨🇳 **国产数据库**：[bytebase](https://github.com/bytebase/bytebase)（+21）—— Database governance built for humans and agents — controllin
- 🤖 **AI工具**：[powercontext](https://github.com/oceanbase/powercontext)（+862）—— PowerContext: The Next Generation of PowerMem.



## 🗄️ 板块一 · 国际主流数据库
> 范围：Oracle / SQL Server / DB2 / MySQL / PostgreSQL / MariaDB / ClickHouse。仅收录上述数据库生态的开源工具，不含 AI 项目。

### 🔥 活跃榜 Top3

> 🥇 **[drawdb-io/drawdb](https://github.com/drawdb-io/drawdb)** · ⭐ 39.1k · 本周 **+552**
> `其他` · 适用：Oracle / PostgreSQL / MariaDB
> Free, simple, and intuitive online database diagram editor and SQL generator.
> 🤖 **AI 解读**：drawDB是浏览器端数据库ER图编辑器，支持Oracle、PostgreSQL、MariaDB等，可绘制关系图、生成SQL脚本及迁移，无需注册，数据存于本地。

> 🥈 **[grafana/grafana](https://github.com/grafana/grafana)** · ⭐ 76.3k · 本周 **+130**
> `监控` · 适用：MySQL / PostgreSQL
> The open and composable observability and data visualization platform. Visualize
> 🤖 **AI 解读**：Grafana是开源可观测性与数据可视化平台，支持查询MySQL、PostgreSQL等数据库指标，创建动态仪表盘，并基于数据定义告警规则。

> 🥉 **[dbeaver/dbeaver](https://github.com/dbeaver/dbeaver)** · ⭐ 51.5k · 本周 **+99**
> `其他` · 适用：11+种数据库（Oracle / SQL Server / DB2等）
> Free universal database tool and SQL client
> 🤖 **AI 解读**：DBeaver跨平台数据库工具，支持Oracle、SQL Server、DB2、MySQL、PostgreSQL及JDBC/ODBC驱动数据库，提供SQL编辑

### 🌱 新锐发现（最多 3 个）

> ① **[rexadbapp/RexaDB](https://github.com/rexadbapp/RexaDB)** · ⭐ 9 · 本周 **+9**
> `其他` · 适用：SQL Server / MySQL / PostgreSQL / ClickHouse
> Multi-database desktop client for PostgreSQL, MySQL, MongoDB, SQLite, ClickHouse
> 🤖 **AI 解读**：RexaDB 是多数据库桌面客户端，支持 PostgreSQL、MySQL、SQL Server、ClickHouse 等，提供查询编辑

### 🔍 本周解读 · drawdb

> 🔍 **[drawdb-io/drawdb](https://github.com/drawdb-io/drawdb)** · ⭐ 39.1k · 本周 **+552**
> `其他` · 适用：Oracle / PostgreSQL / MariaDB
> Free, simple, and intuitive online database diagram editor and SQL generator.

**解决什么**：一个基于浏览器的数据库实体关系图编辑器，用于可视化设计数据库表结构，并自动生成对应SQL脚本，免去手动编写建表语句的繁琐过程。

**核心亮点**：支持Oracle、PostgreSQL、MariaDB等数据库的建表脚本生成与导入。提供直观的拖拽式图表编辑界面。可导出SQL脚本、生成迁移文件，并支持自定义编辑器外观。无需注册账号即可使用全部功能。

**使用场景**：适用于数据库设计阶段的快速建模与文档化，也适合开发者在编写建表语句前进行可视化验证，以及教学场景中演示数据库结构设计。支持本地开发环境部署，也可通过Docker容器化运行。



## 🇨🇳 板块二 · 国内数据库
> 范围：openGauss / GaussDB / TiDB / OceanBase / TDSQL / PolarDB / PolarDB-X / YashanDB / GBase / DM / GoldenDB。仅收录上述数据库生态的开源项目（内核以各厂商官方为准），不含 AI 项目。

### 🔥 活跃榜 Top3

> 🥇 **[bytebase/bytebase](https://github.com/bytebase/bytebase)** · ⭐ 14.4k · 本周 **+21**
> `管理` · 适用：8+种数据库（Oracle / SQL Server / MySQL等）
> Database governance built for humans and agents — controlling changes and access
> 🤖 **AI 解读**：Bytebase是开源数据库治理平台，统一管理变更与访问。支持十余种数据库，提供SQL审核、GitOps集成及细粒度权限控制

> 🥈 **[ClouGence/open-cdm](https://github.com/ClouGence/open-cdm)** · ⭐ 358 · 本周 **+17**
> `管理` · 适用：12+种数据库（Oracle / SQL Server / DB2等）
> A free and open-source database management tool, suitable for team use. It offer
> 🤖 **AI 解读**：开源数据库管理工具，面向团队协作，提供访问控制、数据脱敏、SQL审计及CI/CD能力，支持跨地域部署。兼容Oracle、SQL Server、DB2

> 🥉 **[tikv/raft-rs](https://github.com/tikv/raft-rs)** · ⭐ 3.4k · 本周 **+5**
> `其他` · 适用：TiDB
> Raft distributed consensus algorithm implemented in Rust.
> 🤖 **AI 解读**：raft-rs是Rust实现的Raft共识算法库，用于构建容错分布式系统。TiDB等数据库可借助它实现日志复制与状态机一致性，保障集群在节点故障时维持数据一致。

### 🌱 新锐发现（最多 3 个）

> ① **[opengauss-mirror/openGauss-MemoryWorkload](https://github.com/opengauss-mirror/openGauss-MemoryWorkload)** · ⭐ 0 · 近7天 1 commits
> `其他` · 适用：openGauss
> 🤖 **AI 解读**：该项目为openGauss的内存工作负载相关工具，面向openGauss数据库使用者，提供内存场景下的负载模拟与测试能力，辅助评估数据库在内存型业务中的表现。

### 🔍 本周解读 · bytebase

> 🔍 **[bytebase/bytebase](https://github.com/bytebase/bytebase)** · ⭐ 14.4k · 本周 **+21**
> `管理` · 适用：8+种数据库（Oracle / SQL Server / MySQL等）
> Database governance built for humans and agents — controlling changes and access across every major database.

**解决什么**：数据库变更与访问管控分散在多个工具中，导致流程割裂、权限失控且难以审计。Bytebase 提供一个统一控制平面，将变更管理、访问控制与合规记录整合，覆盖人工操作与 AI 代理。

**核心亮点**：支持200+SQL审查规则与GUI变更流程，集成GitOps实现数据库即代码。提供细粒度RBAC、临时访问授权与动态列级脱敏。内置MCP服务器，支持文本生成SQL及自然语言驱动的自动化操作。

**使用场景**：适用于需规范化数据库变更的开发团队、集中管理多环境实例的DBA，及要求敏感数据访问控制与审计轨迹的安全合规场景。支持MySQL、PostgreSQL、Oracle、SQL Server、TiDB



## 🤖 板块三 · AI 工具
> 范围：板块一 / 板块二所列数据库生态的 AI 辅助工具（text2sql / AI DBA / DB-MCP 等）。

### 🔥 活跃榜 Top3

> 🥇 **[oceanbase/powercontext](https://github.com/oceanbase/powercontext)** · ⭐ 862 · 本周 **+862**
> `其他` · 适用：OceanBase
> PowerContext: The Next Generation of PowerMem.
> 🤖 **AI 解读**：PowerContext为AI代理提供持久化、项目级上下文记忆，支持跨会话恢复决策与状态。基于轻量级文件数据库存储，含本地服务与客户端

> 🥈 **[OtterMind/Chat2DB](https://github.com/OtterMind/Chat2DB)** · ⭐ 28.0k · 本周 **+91**
> `管理` · 适用：8+种数据库（Oracle / SQL Server / DB2等）
> Chat2DB is a free, cross-platform, local-first database client and SQL workspace
> 🤖 **AI 解读**：Chat2DB为跨平台数据库客户端，支持40余种数据库，提供SQL编辑执行、数据管理及AI辅助生成与优化查询，支持桌面、Web、Docker及CLI部署。

> 🥉 **[Canner/WrenAI](https://github.com/Canner/WrenAI)** · ⭐ 17.3k · 本周 **+74**
> `平台` · 适用：PostgreSQL / ClickHouse
> GenBI (Generative BI) for AI agents, an open-source, governed text-to-SQL throug
> 🤖 **AI 解读**：WrenAI为开源生成式BI引擎，经语义层将自然语言转SQL，支持PostgreSQL、ClickHouse等20余种数据源

### 🌱 新锐发现（最多 3 个）

> ① **[yiaany/Mekka](https://github.com/yiaany/Mekka)** · ⭐ 4 · 本周 **+4**
> `平台` · 适用：PostgreSQL
> The agent-native Supabase killer: SQLite speed today, distributed cloud next, wi
> 🤖 **AI 解读**：Mekka是集成数据库、认证、存储、实时更新及管理界面的Bun项目，基于轻量级文件数据库运行，兼容PostgreSQL部分行为，提供MCP代理访问

### 🔍 本周解读 · powercontext

> 🔍 **[oceanbase/powercontext](https://github.com/oceanbase/powercontext)** · ⭐ 862 · 本周 **+862**
> `其他` · 适用：OceanBase
> PowerContext: The Next Generation of PowerMem.

**解决什么**：PowerContext为AI代理提供跨会话的持久化项目上下文，使后续会话无需依赖聊天记录即可恢复决策、结果、当前状态或下一步操作，解决代理记忆丢失问题。

**核心亮点**：基于轻量级文件数据库的本地服务存储项目级上下文，提供异步Python客户端、Core SDK、CLI及Codex插件，支持HTTP与MCP协议集成非Python进程

**使用场景**：适用于需跨会话保持项目记忆的AI编码代理，如Codex CLI用户；适合Python应用集成持久化上下文，或经HTTP/MCP接入非Python代理；也适合诊断和检查代理记忆内容的开发环境。



## 📊 Top 总榜（历史 Star 总数）

| 项目 | 总 Star | 板块 | 分类 | 一句话定位 |
| :--- | ---: | :--- | :--- | :--- |
| **[grafana/grafana](https://github.com/grafana/grafana)** | 76.3k | 国外数据库 | 监控 | The open and composable observability and data visualization platform. |
| **[dbeaver/dbeaver](https://github.com/dbeaver/dbeaver)** | 51.5k | 国外数据库 | 其他 | Free universal database tool and SQL client |
| **[drawdb-io/drawdb](https://github.com/drawdb-io/drawdb)** | 39.1k | 国外数据库 | 其他 | Free, simple, and intuitive online database diagram editor and SQL gen |
| **[OtterMind/Chat2DB](https://github.com/OtterMind/Chat2DB)** | 28.0k | AI工具 | 管理 | Chat2DB is a free, cross-platform, local-first database client and SQL |
| **[sinaptik-ai/pandas-ai](https://github.com/sinaptik-ai/pandas-ai)** | 23.7k | AI工具 | 其他 | Chat with your database or your datalake (SQL, CSV, parquet). PandasAI |



## 💬 互动与说明

- 💬 **互动**：本周你最关注哪个项目？欢迎留言分享你的试用体验。
- 📌 **板块范围**：板块一 Oracle / SQL Server / DB2 / MySQL / PostgreSQL / MariaDB / ClickHouse；板块二 openGauss / GaussDB / TiDB / OceanBase / TDSQL / PolarDB / PolarDB-X / YashanDB / GBase / DM / GoldenDB；板块三为上述数据库生态的 AI 辅助工具。范围外数据库项目不入周报。
- 📌 **说明**：由 `ai_db_weekly` 基于 GitHub 数据自动采集（截至 2026-08-14）。项目描述来自 GitHub 项目的 description 字段；AI 解读基于项目 README，由 AI 生成，仅供参考。国产数据库板块仅收录在 GitHub 上活跃的开源项目，内核以各厂商官方为准。分类字段采用固定枚举值。


---
