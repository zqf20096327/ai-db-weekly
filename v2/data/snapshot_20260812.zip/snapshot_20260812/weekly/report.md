> **数据库开源周报 · 第 N 期**
> 每周 5 分钟，追踪数据库工具与生态的一手动态。
> _2026-08-12_

> 📌 **数据边界**：本报告聚焦数据库**工具与生态**。数据库内核（PostgreSQL/MySQL/TiDB 等）的版本与发版请以各厂商官方渠道为准。
> 📌 **配套阅读**：本期 [**运维工具合辑周报**](https://mp.weixin.qq.com/)（6 类工具本周动态体检）

---


## ✏️ 本期导语

本周 star 异常上涨（≥100）12 个：powercontext（+850）、write-you-a-vector-db（+783）、drawdb（+631）、WrenAI（+363）、Chat2DB（+295）。
新入榜工具 33 个。
本周 39 个工具发版。
无 License 变更。
详见下方各栏。


## 🔍 本周精选解读

### 1. WrenAI wren-core-py-v0.7.4

[Canner/WrenAI](https://github.com/Canner/WrenAI) · ⭐ 17.2k（+363） · [发版说明](https://github.com/Canner/WrenAI/releases/tag/wren-core-py-v0.7.4)

**发生了什么**：本周发布了 wren-core-py-v0.7.4 版本，核心变更为一项 Bug 修复：在 Python 绑定中声明了其编译所依赖的引擎版本。该修复通过 PR #2659 实现，提交编号为 92cdf43，发布于 2026 年 8 月 11 日。此次更新旨在确保 Python 绑定与底层 Rust 引擎的版本兼容性，避免因版本不匹配导致的潜在问题。

**为什么值得关注**：WrenAI 是一个开源的生成式商业智能（GenBI）引擎，面向 AI 代理设计，解决的是让代理生成可信、可治理的 SQL 查询和仪表盘的问题。其核心能力包括：通过开放的 AI 上下文层和语义层（MDL）将自然语言问题转化为受治理的 text-to-SQL，支持 22+ 数据源（如 BigQuery、Snowflake、PostgreSQL 等），并能将查询结果部署为可分享的浏览器端仪表盘。该工具强调知识管理，将业务定义、示例和记忆以版本化、可审查的 Git 友好文件形式存储，同时提供干计划验证、行数限制和结构化错误等治理执行原语。项目采用 Apache 2.0 开源协议，采用开放核心模式，部分高级功能（如行/列级安全、GenBI UI）为商业版本提供。

### 2. Chat2DB v5.3.3

[OtterMind/Chat2DB](https://github.com/OtterMind/Chat2DB) · ⭐ 27.9k（+295） · [发版说明](https://github.com/OtterMind/Chat2DB/releases/tag/v5.3.3)

**发生了什么**：Chat2DB Community 5.3.3 于本周发布，主要聚焦桌面端工作区、集成终端和本地文件体验的改进。该版本新增了集成终端、本地文件预览、工作区分屏、可配置的 SQL 与数据库树快捷键、MiniMax 模型提供商支持，以及跨数据库方言的无条件标识符引用功能。此外，版本包含 95 项修复，覆盖跨数据库 SQL 与 DDL 安全、DML 与分页校验、存储一致性、结果网格、AI 流所有权、BI 图表、数据库兼容性以及 macOS 打包与启动问题。开发与发布工程方面，涉及社区 Web 与 JCEF 启动器、严格发布元数据生成、桌面字节码验证及仅回环的受监督开发运行时。共有 9 位贡献者参与，其中 2 位为首次贡献。

**为什么值得关注**：Chat2DB 是一个 AI 驱动的数据库客户端和 SQL 工作台，面向开发者、DBA、分析师和数据团队，支持 40 多种数据库（如 MySQL、PostgreSQL、Oracle、SQL Server、ClickHouse、MongoDB、Redis 等），并可通过配置扩展新的 JDBC 数据库。其核心能力包括完整的 SQL 编辑、补全、格式化与执行，AI 助手（可接入自有模型）用于自然语言生成、解释和优化 SQL，以及数据库元数据浏览、对象管理（DDL/DML）、数据就地编辑、导入导出和仪表盘图表。该工具以本地优先、单用户模式运行，支持 Windows、macOS、Linux 桌面端及 Docker 部署，并强调数据安全（如 AES-256-GCM 加密存储密码和 API 密钥）。社区版为免费开源，商业版在此基础上增加托管 AI 服务、用户账户、云同步与团队协作功能。

### 3. grafana v13.0.6

[grafana/grafana](https://github.com/grafana/grafana) · ⭐ 76.2k（+153） · [发版说明](https://github.com/grafana/grafana/releases/tag/v13.0.6)

**发生了什么**：grafana/grafana 本周发布了 v13.0.6 版本。该版本为维护性发版，主要包含 bug 修复和稳定性改进，具体变更细节需查阅官方 Release Notes 页面。用户可通过官方下载页面获取该版本，并参考“What's new highlights”文档了解新版本特性概览。

**为什么值得关注**：Grafana 是一个开源的可观测性与数据可视化平台，旨在帮助用户查询、可视化、告警并理解来自多种数据源（如 Prometheus、Loki、Elasticsearch、InfluxDB、Postgres 等）的指标、日志和追踪数据。其核心能力包括：支持多种可视化面板插件，可创建带模板变量的动态可复用仪表盘；提供指标探索与日志探索功能，支持临时查询、动态下钻及分屏对比；内置可视化告警规则定义与通知集成（如 Slack、PagerDuty 等）；并允许在同一图表中混合使用不同数据源。该工具适用于需要统一监控、分析与展示多源数据的运维、开发及数据分析场景。项目采用 AGPL-3.0-only 许可证。




## 📋 工具动态速递

> 本周有发版或显著活跃的数据库工具，每条一句话。无动静的工具不在列。

- 🏷️ `0.12.0` 🔥62c 📈+142 **[fastapi/full-stack-fastapi-template](https://github.com/fastapi/full-stack-fastapi-template)** — Full-stack web application template with FastAPI, React, SQLModel, PostgreSQL, Vite, Tailwind CSS, shadcn/ui, FastAPI Cloud, and Docker Compose.（⭐ 44.8k）
- 🏷️ `v2.3.1` 🔥131c 📈+60 **[InsForge/InsForge](https://github.com/InsForge/InsForge)** — The all-in-one, open-source backend platform for agentic coding. InsForge gives your coding agent database, auth, storage, compute, hosting, and AI gateway to ship full-stack apps end-to-end.（⭐ 12.7k）
- 🏷️ `v0.28.0-beta.1` 🔥43c 📈+115 **[warp-tech/warpgate](https://github.com/warp-tech/warpgate)** — Fully transparent SSH, HTTPS, Kubernetes, MySQL and Postgres bastion/PAM that doesn't need additional client-side software（⭐ 7.6k）
- 🏷️ `v6.0.0` 🔥100c 📈+45 **[beekeeper-studio/beekeeper-studio](https://github.com/beekeeper-studio/beekeeper-studio)** — Modern and easy to use SQL client for MySQL, Postgres, SQLite, SQL Server, and more. Linux, MacOS, and Windows.（⭐ 23.4k）
- 🏷️ `v3.1.0` 🔥117c 📈+21 **[HelixDB/helix-db](https://github.com/HelixDB/helix-db)** — HelixDB is an OLTP graph-vector database built in Rust on Object Storage.（⭐ 5.7k）
- 🏷️ `4.0.3` 🔥115c 📈+18 **[pawelsalawa/letos](https://github.com/pawelsalawa/letos)** — A free, open source, multi-platform SQLite database manager.（⭐ 6.7k）
- 🏷️ `production/5.4.0-20109` 🔥96c 📈+16 **[Sequel-Ace/Sequel-Ace](https://github.com/Sequel-Ace/Sequel-Ace)** — MySQL/MariaDB database management for macOS（⭐ 7.5k）
- 🏷️ `v8.0.0-rc.1` 🔥41c 📈+27 **[prisma/prisma](https://github.com/prisma/prisma)** — Next-generation ORM for Node.js & TypeScript / PostgreSQL, MySQL, MariaDB, SQL Server, SQLite, MongoDB and CockroachDB（⭐ 47.6k）



## 🆕 新生项目

> 30 天内创建 + star ≥ 3，经相关性过滤。潜力榜已发酵，新星榜为早期观察。

### 🌟 潜力榜（star ≥ 30，已发酵）

| 项目 | 作用 | Star | 创建日 |
|---|---|---:|---|
| [albertoarena/laravel-truss](https://github.com/albertoarena/laravel-truss) | A live database structure viewer for Laravel that renders your schema as a scrollable, zoomable ER diagram. Structure only, never data. | 185 | 2026-07-22 |
| [LunarPy-Labs/LunarDump](https://github.com/LunarPy-Labs/LunarDump) | A lightweight, zero-trust CLI tool built in Python to automate, encrypt, and stream database backups directly to multi-cloud storage. | 38 | 2026-07-29 |
| [autumoswitzerland/Webduck](https://github.com/autumoswitzerland/Webduck) | A self-hosted DuckDB-as-a-Service server with REST API and Web UI. | 38 | 2026-07-24 |
| [MrXujiang/opne-aureka](https://github.com/MrXujiang/opne-aureka) | Upload spreadsheets, ask questions via chat, and auto-generate chart reports. No coding required, gain instant insights and unlock data value effortlessly. ｜上传表格，像聊天一样提问，系统自动分析生成图表报告。无需编程，即时洞察，数据价值触手可及。 | 31 | 2026-07-31 |
| [tnandla/portfolio-os](https://github.com/tnandla/portfolio-os) | Self-hosted operations app for teams running a portfolio of websites: projects, an encrypted credential vault, content work, people and money. Laravel + Livewire, runs on PHP/MySQL shared hosting. | 61 | 2026-08-05 |

### 🆕 新星榜（star 3 ~ 30，早期观察）

> 📌 本档为早期观察信号，仅作记录，不代表成熟可用。

| 项目 | 作用 | Star |
|---|---|---:|
| [h5i-dev/h5i-db](https://github.com/h5i-dev/h5i-db) | An agent-native workspace for quantitative research: an in-terminal notebook, a high-performance time-series database, and a high-throughput backtesting engine. Written in Rust. | 28 |
| [Dicklesworthstone/frankengraphdb](https://github.com/Dicklesworthstone/frankengraphdb) | A blank-slate, memory-safe, ultra-high-performance property-graph database in Rust — unified MVCC/time-travel/branches/replication over a fountain-coded commit stream, WCO+factorized execution, incremental everything, and deterministic auditable results. | 20 |
| [hstptcn5/Catena](https://github.com/hstptcn5/Catena) | Catena exposes any SQLite database as a secure HTTP + WebSocket API in one small Go binary. | 14 |
| [backenly/backenly](https://github.com/backenly/backenly) | Autonomous backend platform. Your coding agent builds it over MCP, Backenly keeps it running: Postgres, REST APIs, auth, storage, realtime, and functions, with every change governed, verified, and reversible. | 14 |
| [ridi-oss/proxy-monster](https://github.com/ridi-oss/proxy-monster) | Self-hosted database access-control proxy for MySQL and PostgreSQL: lineage-aware column masking, Cedar policy, fail-closed deny, tamper-evident audit trail. | 14 |



## 📊 Top 总榜

> 数据库工具按 star 降序。数据库内核（PostgreSQL/MySQL/Redis 等）不在此列，请关注各厂商官方渠道。

| 排名 | 项目 | Star | 作用 |
|:--:|---|---:|---|
| 1 | [grafana/grafana](https://github.com/grafana/grafana) | 76.2k | The open and composable observability and data visualization platform. Visualize metrics, logs, and traces from multiple sources like Prometheus, Loki, Elasticsearch, InfluxDB, Postgres and many more. |
| 2 | [nocodb/nocodb](https://github.com/nocodb/nocodb) | 64.5k | 🔥 🔥 🔥 A Free & Self-hostable Airtable Alternative |
| 3 | [dbeaver/dbeaver](https://github.com/dbeaver/dbeaver) | 51.4k | Free universal database tool and SQL client |
| 4 | [prisma/prisma](https://github.com/prisma/prisma) | 47.6k | Next-generation ORM for Node.js & TypeScript / PostgreSQL, MySQL, MariaDB, SQL Server, SQLite, MongoDB and CockroachDB |
| 5 | [fastapi/full-stack-fastapi-template](https://github.com/fastapi/full-stack-fastapi-template) | 44.8k | Full-stack web application template with FastAPI, React, SQLModel, PostgreSQL, Vite, Tailwind CSS, shadcn/ui, FastAPI Cloud, and Docker Compose. |
| 6 | [drawdb-io/drawdb](https://github.com/drawdb-io/drawdb) | 38.9k | Free, simple, and intuitive online database diagram editor and SQL generator. |
| 7 | [sqlmapproject/sqlmap](https://github.com/sqlmapproject/sqlmap) | 38.2k | Automatic SQL injection and database takeover tool |
| 8 | [typeorm/typeorm](https://github.com/typeorm/typeorm) | 36.6k | TypeScript & JavaScript ORM for Node.js — supports PostgreSQL, MySQL, MariaDB, SQLite, SQL Server, Oracle, and more. |
| 9 | [sequelize/sequelize](https://github.com/sequelize/sequelize) | 30.4k | Feature-rich ORM for modern Node.js and TypeScript, it supports PostgreSQL (with JSON and JSONB support), MySQL, MariaDB, SQLite, MS SQL Server, Snowflake, Oracle DB, DB2 and DB2 for IBM i. |
| 10 | [chroma-core/chroma](https://github.com/chroma-core/chroma) | 29.0k | Search infrastructure for AI |

📎 来源:[GitHub API](https://api.github.com)



## ⚖️ License 雷达

> License 变更可能影响商用，是选型关键信号。

本期无 license 变更事件。



## 📌 关于本报告

**📊 统计口径**
- 数据来自 GitHub 公开 API，截至 2026-08-12
- 仅含数据库**工具**类项目；内核库（PG/MySQL/TiDB 等）版本请关注厂商官方渠道
- "新生项目" = 30 天内创建且 star ≥ 3；"活跃度" = 近 7 日 commit 数

**📎 数据说明**
- Search API 存在索引延迟，新建项目可能滞后数天被索引
- 编辑点评基于项目 release notes 与 README，信息以各项目官方为准

**📂 配套阅读**
- 本期 [**运维工具合辑周报**](https://mp.weixin.qq.com/)：6 类工具本周动态体检、新晋工具、静默观察、类目趋势（发布后替换为链接）


---

**🗂️ 往期回顾 ｜ 👍 点赞 + 在看 ｜ 🔔 关注「数据库开源周报」**
